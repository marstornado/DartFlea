/** Automatically generated file. DO NOT MODIFY */
package org.madmatrix.zxing.android;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}