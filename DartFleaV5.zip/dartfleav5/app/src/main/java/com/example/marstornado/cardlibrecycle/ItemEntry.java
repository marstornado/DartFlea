package com.example.marstornado.cardlibrecycle;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

/**
 * Created by zhenma on 3/5/15.
 */
public class ItemEntry {

    private static String TAG = "ItemEntry";

    public static String FIELD_NAME_ID = "id";
    public static String FIELD_NAME_ITEM_ID = "itemId";
    public static String FIELD_NAME_USER_ID = "userid";
    public static String FIELD_NAME_ITEMNAME = "itemname";
    public static String FIELD_NAME_PRICE = "price";
    public static String FIELD_NAME_DESCRIPTION = "description";
    public static String FIELD_NAME_STATUS = "status";
    public static String FIELD_NAME_CATEGORY = "category";
    public static String FIELD_NAME_BARCODE = "barcode";
    public static String FIELD_NAME_DATETIME = "datetime";
    public static String FIELD_NAME_IMAGES = "images";
    public static String FIELD_NAME_COMPARE_IMAGE = "compare_images";
    public static String FIELD_NAME_COMPARE_PRICE = "compare_price";

    private long id;
    private long userId;
    private String name;
    private double price;
    private String description;
    private int status;
    private int category;
    private long barcode;
    private long datetime;
    private ArrayList<String> image_urls;
    private String compare_image;
    private double compare_price;

    //store the picture ID in an arraylist
    private ArrayList<Long> images;



    //
    public ItemEntry() {
        this.userId = 0;
        this.name = "";
        this.price = 0;
        this.description = "";
        this.status = 0;
        this.category = 0;
        this.barcode = 0;
        this.datetime = 0;
        //this.images = new ArrayList<Long>();
        this.image_urls = new ArrayList<String>();
        this.compare_image = "";
        this.compare_price = 0;
    }

    public ItemEntry(long itemId, long userId, String name, double price, String description, int status,
                     int category, long barcode, long datetime, ArrayList<String> image_urls,
                     String compare_image, double compare_price) {
        this.id = itemId;
        this.userId = userId;
        this.name = name;
        if(name == null)
            this.name = "";
        this.price = price;
        this.description = description;
        if(description == null)
            this.description = "";
        this.status = status;
        this.category = category;
        this.barcode = barcode;
        this.datetime = datetime;
        this.image_urls = image_urls;
        this.compare_image = compare_image;
        if(compare_image == null)
            this.compare_image = "";
        this.compare_price = compare_price;
    }

    public ItemEntry(JSONObject json){
        if(json == null){
            Log.d(TAG, "json object is null");
        }
        try {
            this.id = json.getLong(FIELD_NAME_ID);
            this.userId = json.getLong(FIELD_NAME_USER_ID);
            this.name = json.getString(FIELD_NAME_ITEMNAME);
            this.price = json.getDouble(FIELD_NAME_PRICE);
            this.description = json.getString(FIELD_NAME_DESCRIPTION);
            this.status = json.getInt(FIELD_NAME_STATUS);
            this.category = json.getInt(FIELD_NAME_CATEGORY);
            this.barcode = json.getLong(FIELD_NAME_BARCODE);
            this.datetime = json.getLong(FIELD_NAME_DATETIME);

            this.image_urls = new ArrayList<String>();
            String json_string = json.getString(FIELD_NAME_IMAGES);
            JSONObject jo = new JSONObject(json_string);
            JSONArray array = jo.getJSONArray("images");
            int size = array.length();
            for(int i=0;i<size;i++){
     		   JSONObject obj = array.getJSONObject(i);
                this.image_urls.add(obj.getString("url"));
            }


            this.compare_image = json.getString(FIELD_NAME_COMPARE_IMAGE);
            this.compare_price = json.getDouble(FIELD_NAME_COMPARE_PRICE);

//            this.mItemId = json.getLong(FIELD_NAME_ITEM_ID);
//            this.mUserId = json.getLong(FIELD_NAME_USER_ID);
//            this.mItemname = json.getString(FIELD_NAME_ITEMNAME);
//            this.mPrice = json.getDouble(FIELD_NAME_PRICE);
//            this.mDescription = json.getString(FIELD_NAME_DESCRIPTION);
//            this.mStatus = json.getInt(FIELD_NAME_STATUS);
//            this.mCategory = json.getInt(FIELD_NAME_CATEGORY);
//            this.mBarcode = json.getLong(FIELD_NAME_BARCODE);
//            this.mDatetime = json.getLong(FIELD_NAME_DATETIME);
//            this.mImages = json.getString(FIELD_NAME_IMAGES);
////            this.mImages = new ArrayList<String>();
////            String json_string = json.getString(FIELD_NAME_IMAGES);
////            JSONObject jo = new JSONObject(json_string);
////            JSONArray array = jo.getJSONArray("images");
////            int size = array.length();
////            for(int i=0;i<size;i++){
////     		   JSONObject obj = array.getJSONObject(i);
////     		   this.mImages.add(obj.getString("url"));
////            }
//            this.mCompareImage = json.getString(FIELD_NAME_COMPARE_IMAGE);
//            this.mComparePrice = json.getDouble(FIELD_NAME_COMPARE_PRICE);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public JSONObject getJSONObject(){
        JSONObject json = new JSONObject();
        try{
            json.put(FIELD_NAME_ITEM_ID, id);
            json.put(FIELD_NAME_USER_ID, userId);
            json.put(FIELD_NAME_ITEMNAME, name);

            json.put(FIELD_NAME_PRICE, price);
            json.put(FIELD_NAME_DESCRIPTION, description);
            json.put(FIELD_NAME_STATUS, status);

            json.put(FIELD_NAME_CATEGORY, category);
            json.put(FIELD_NAME_BARCODE, barcode);
            json.put(FIELD_NAME_DATETIME, datetime);

            JSONArray array = new JSONArray();
            for(String url : image_urls){
                JSONObject jo = new JSONObject();
                jo.put("url", url);
                array.put(jo);
            }
            JSONObject obj = new JSONObject();
            obj.put("images", array);
            json.put(FIELD_NAME_IMAGES, obj);
            json.put(FIELD_NAME_COMPARE_IMAGE, compare_image);
            json.put(FIELD_NAME_COMPARE_PRICE, compare_price);
        }catch(Exception e){
            e.printStackTrace();
        }
        return json;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getCategory() {
        return category;
    }

    public void setCategory(int category) {
        this.category = category;
    }

    public long getBarcode() {
        return barcode;
    }

    public void setBarcode(long barcode) {
        this.barcode = barcode;
    }

    public ArrayList<Long> getMpicture(){return images;}

    public void setMpicture(ArrayList<Long> mp){this.images=mp;}

    public ArrayList<String> getImage_urls() {
        return image_urls;
    }

    public void setImage_urls(ArrayList<String> image_urls) {
        this.image_urls = image_urls;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public String getCompare_image() {
        return compare_image;
    }

    public void setCompare_image(String compare_image) {
        this.compare_image = compare_image;
    }

    public double getCompare_price() {
        return compare_price;
    }

    public void setCompare_price(double compare_price) {
        this.compare_price = compare_price;
    }

    public long getDatetime() {
        return datetime;
    }

    public void setDatetime(long datetime) {
        this.datetime = datetime;
    }

    public String getmDateTimeString(){
        Calendar time = Calendar.getInstance();
        time.setTimeInMillis(datetime);
        SimpleDateFormat formatter = new SimpleDateFormat("hh:mm:ss MMM dd yyyy");
        return formatter.format(time.getTime());
    }

    public String toString(){
        return "id = " + id + ", userId = "
                + userId + ", name = " + name + ", price = "
                + price + ", description = " + description + ", status = "
                + status + ", category = " + category + ", barcode = "
                + barcode + ", time = " + getmDateTimeString() + ", images = " + image_urls.get(0) +
                ", compare_image = "

                + compare_image + ", compare_price = " + compare_price;
    }
}
