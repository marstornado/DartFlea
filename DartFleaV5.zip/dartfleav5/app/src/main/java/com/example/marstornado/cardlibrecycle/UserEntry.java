package com.example.marstornado.cardlibrecycle;

/**
 * Created by zhenma on 3/5/15.
 */
public class UserEntry {

    private long id;

    private String username;
    private String Email;
    private String password;
    private int motivation;
    private long phone;
    private byte[] image;
//    private List<String> contacts;


    public UserEntry(){
        this.username = "";
        this.Email = "";
        this.password  = "";
        this.motivation = 0;
        this.phone = 0;
        this.image = new byte[1];
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getMotivation() {
        return motivation;
    }

    public void setMotivation(int motivate) {
        this.motivation = motivate;
    }

    public long getPhone() {
        return phone;
    }

    public void setPhone(long phone) {
        this.phone = phone;
    }

    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }

//    public List<String> getContacts() {
//        return contacts;
//    }
//
//    public void setContacts(List<String> contacts) {
//        this.contacts = contacts;
//    }


}
