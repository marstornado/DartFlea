package com.example.marstornado.cardlibrecycle;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by menglingli on 3/6/15.
 */
public class UserDatabaseHelper extends SQLiteOpenHelper {
    private static final String TAG = "User DB";

    // All Static variables
// Database Version
    private static final int DATABASE_VERSION = 1;

    // Database Name
    private static final String DATABASE_NAME = "user.db";

    // Contacts table name
    private static final String TABLE_ENTRIES = "users";

    // Contacts Table Columns names
    private static final String KEY_ID = "_id";
    private static final String KEY_USERNAME = "mUsername";
    private static final String KEY_EMAIL = "mEmail";
    private static final String KEY_PASSWORD = "mPassword";
    private static final String KEY_MOTIVATION = "mLatitude";
    private static final String KEY_PHONE = "mPhone";
    private static final String KEY_IMAGE = "mImage";
    private static final String KEY_CONTACTS = "mContacts";




    private String[] allColumns = { KEY_ID,KEY_USERNAME, KEY_EMAIL,
            KEY_PASSWORD, KEY_MOTIVATION, KEY_PHONE,KEY_IMAGE,KEY_CONTACTS};

    public UserDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Creating Tables
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_CONTACTS_TABLE = "CREATE TABLE IF NOT EXISTS " + TABLE_ENTRIES + "("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + KEY_USERNAME +" TEXT, "
                + KEY_EMAIL + " TEXT, "
                + KEY_PASSWORD + " FLOAT, "
                + KEY_MOTIVATION + " FLOAT, "
                + KEY_PHONE + " FLOAT, "
                + KEY_IMAGE + " BLOB, "
                + KEY_CONTACTS + " TEXT "
                + ");";
        db.execSQL(CREATE_CONTACTS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.w(PictureDatabaseHelper.class.getName(),
                "Upgrading database from version " + oldVersion + " to "
                        + newVersion + ", which will destroy all old data");
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ENTRIES);
        onCreate(db);
    }

    public long addUserEntry(UserEntry entry) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_CONTACTS, entry.getUsername());
        values.put(KEY_EMAIL, entry.getEmail());
        values.put(KEY_PASSWORD, entry.getPassword());
        values.put(KEY_MOTIVATION, entry.getMotivation());
        values.put(KEY_PHONE, entry.getPhone());
        values.put(KEY_IMAGE,entry.getImage());


//        if(entry.getContacts() != null){
//            List<String> arrayList = entry.getContacts();
//            StringBuffer sb = new StringBuffer();
//            for(int i=0;i<arrayList.size();i++){
//                sb.append(arrayList.get(i)).append(',');
//            }
//            values.put(KEY_CONTACTS,sb.toString());
//        }

        long insertId = db.insert(TABLE_ENTRIES, null, values);
        db.close(); // Closing database connection
        return insertId;
    }

    public List<UserEntry> getAllUserEntries() {
        List<UserEntry> userEntries = new ArrayList<UserEntry>();
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.query(TABLE_ENTRIES,
                allColumns, null, null, null, null, null);


        Log.d(TAG, "row number in the cursor: " + cursor.getCount());

        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            UserEntry entry = cursorToUserEntry(cursor);
            Log.d(TAG, "get entry = " + cursorToUserEntry(cursor).toString());
            userEntries.add(entry);
            cursor.moveToNext();
        }

        // Make sure to close the cursor
        cursor.close();
        db.close();
        return userEntries;
    }

    public UserEntry getUserEntryById(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.query(TABLE_ENTRIES,
                allColumns, KEY_ID + " = " + id, null,
                null, null, null);
        cursor.moveToFirst();
        UserEntry userentry = cursorToUserEntry(cursor);

        // Log the comment stored
        Log.d(TAG, "get exercise entry = " + cursorToUserEntry(cursor).toString()
                + " with ID = " + id);

        cursor.close();
        db.close();
        return userentry;
    }

    public void deleteUserEntryById(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        Log.d(TAG, "delete entry = " + id);
        db.delete(TABLE_ENTRIES, KEY_ID + " = " + id, null);
        db.close();
    }

    public void deleteAllItemEntries() {
        SQLiteDatabase db = this.getWritableDatabase();
        Log.d(TAG, "delete all = ");
        db.delete(TABLE_ENTRIES, null, null);
        db.close();
    }


    private UserEntry cursorToUserEntry(Cursor cursor) {
        UserEntry userEntry = new UserEntry();

        userEntry.setId(cursor.getLong(0));
        userEntry.setUsername(cursor.getString(1));
        userEntry.setEmail(cursor.getString(2));
        userEntry.setPassword(cursor.getString(3));
        userEntry.setMotivation(cursor.getInt(4));
        userEntry.setPhone(cursor.getLong(5));
        userEntry.setImage(cursor.getBlob(6));

//        String ss = cursor.getString(7);
//        if(ss != null){
//            ArrayList<String> tmp = new ArrayList<String>();
//            String[] set = ss.split(",");
//            for(String s:set){
//                tmp.add(s);
//            }
//            userEntry.setContacts(tmp);
//        }
        return userEntry;
    }
}
