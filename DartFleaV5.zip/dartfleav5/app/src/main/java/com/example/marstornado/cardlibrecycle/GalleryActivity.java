package com.example.marstornado.cardlibrecycle;

/**
 * Created by huanlu on 2/3/15.
 */

import android.app.ActionBar;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.madmatrix.zxing.android.CaptureActivity;
import org.madmatrix.zxing.android.Intents;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class GalleryActivity extends Activity {

    public static final int REQUEST_CODE_TAKE_FROM_CAMERA = 0;
    public static final int REQUEST_CODE = 200;
    public static final String EXTRA_PICTURE_ID = "extra_picture_id";

    PictureDatabaseHelper db;
    EntryDatabaseHelper edb;
    private ExpandableHeightGridView gridView;
    GridViewAdapter adapter;
    private Uri mImageCaptureUri;
    private Uri mUploadFileUri;
    Location l;
    EditText edittext;
    EditText edit_description;
    Spinner edit_spinner;
    EditText edit_price;
    EditText edit_name;
    RadioGroup edit_radiobutton;
    EditText edit_barcode;
    ArrayList<Long> pics = new ArrayList<Long>();
    ArrayList<String> urls = new ArrayList<String>();
    ItemEntry itemEntry;
    long item_id;
    ArrayList<String> url_names = new ArrayList<String>();
    File file;

    int serverResponseCode = 0;
    ProgressDialog dialog = null;

    String upLoadServerUri = null;

    /**********  File Path *************/
    final String uploadFilePath = Environment.getExternalStorageDirectory().getAbsolutePath()+"/";
    String uploadFileName;

    private ActionBar mActionBar;

//    String root = Environment.getExternalStorageDirectory().toString();
//    File myDir = new File(root);
    WebView webView;
    ImageView imageview;
    String currentUrl;
    String imageUrl;
    String ebayprice;
    ProgressDialog pDialog;
    Bitmap bitmap;
    ScrollView mScrollView;
    TextView priceview;

    private LinearLayout generateLayout;

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gallery_activity_main);
        itemEntry = new ItemEntry();
        edittext = (EditText)findViewById(R.id.edit_barcode);
        db = new PictureDatabaseHelper(this);
        edb = new EntryDatabaseHelper(this);
//        item_id = edb.addItemEntry(itemEntry);
        //db.deleteAllPictures();
//        myDir.mkdirs();
        // Reading all contacts from database
        final List<Picture> pictures = new ArrayList<Picture>();
        //final List<Picture> pictures = db.getAllPicturesForThisItem(item_id);
        gridView = (ExpandableHeightGridView) findViewById(R.id.grid_view);
        gridView.setExpanded(true);
        adapter = new GridViewAdapter(this, R.layout.row_grid, pictures);
        gridView.setAdapter(adapter);

        /************* Php script path ****************/
        upLoadServerUri = "http://www.cs.dartmouth.edu/~marstornado/media/UploadToServer.php";

//        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view,
//                                    int position, long id) {
//                Toast.makeText(getApplicationContext(),
//                        "Item Clicked: " + position, Toast.LENGTH_SHORT).show();
//                Intent i = new Intent(GalleryActivity.this, DisplayImageActivity.class);
//                i.putExtra(EXTRA_PICTURE_ID, pictures.get(position).getId());
//                startActivity(i);
//
//            }
//        });
        mActionBar = getActionBar();
        mActionBar.hide();

        //webview
        priceview = (TextView)findViewById(R.id.price);
        imageview = (ImageView)findViewById(R.id.imageview);
        webView = (WebView)
                findViewById(R.id.webView1);
        mScrollView=(ScrollView) findViewById(R.id.scrollView);
        webView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_UP)
                    mScrollView.requestDisallowInterceptTouchEvent(false);
                else
                    mScrollView.requestDisallowInterceptTouchEvent(true);
                return false;
            }
        });



        webView.setWebViewClient(new WebBrowser());
        webView.getSettings().setLoadsImagesAutomatically(true);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        webView.loadUrl("http://www.google.com");

        generateLayout = (LinearLayout)findViewById(R.id.generate);
        generateLayout.setVisibility(LinearLayout.GONE);
    }


    public void onTakePictureClicked(View v) throws IOException {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        // Construct temporary image path and name to save the taken
        // photo
        String time = String.valueOf(System.currentTimeMillis());
        uploadFileName = time+".jpg";
        file = new File(Environment.getExternalStorageDirectory(),uploadFileName);
        mImageCaptureUri = Uri.fromFile(file);

        urls.add(uploadFileName);
        url_names.add(uploadFileName);

        //uploadFileName = String.valueOf(System.currentTimeMillis()) + ".jpg";
        //url_names.add(uploadFileName);
        intent.putExtra(MediaStore.EXTRA_OUTPUT,
                mImageCaptureUri);
        //intent.putExtra("return-data", true);
        try {
            // Start a camera capturing activity
            // REQUEST_CODE_TAKE_FROM_CAMERA is an integer tag you
            // defined to identify the activity in onActivityResult()
            // when it returns
            startActivityForResult(intent, REQUEST_CODE_TAKE_FROM_CAMERA);
        } catch (ActivityNotFoundException e) {
            e.printStackTrace();
        }

    }

    public void onScanClicked(View v){
        Intent intent = new Intent();
        intent.setAction(Intents.Scan.ACTION);
        // intent.putExtra(Intents.Scan.MODE, Intents.Scan.QR_CODE_MODE);
        intent.putExtra(Intents.Scan.CHARACTER_SET, "");
        intent.putExtra(Intents.Scan.WIDTH, 800);
        intent.putExtra(Intents.Scan.HEIGHT, 600);
        // intent.putExtra(Intents.Scan.PROMPT_MESSAGE, "type your prompt message");
        intent.setClass(this, CaptureActivity.class);
        startActivityForResult(intent, REQUEST_CODE);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode != RESULT_OK)
            return;

        switch (requestCode) {
            case REQUEST_CODE_TAKE_FROM_CAMERA:
                try {
                    // get bitmap from the uri
                    Bitmap bmap = MediaStore.Images.Media.getBitmap
                            (this.getContentResolver(), mImageCaptureUri);

                    //convert bitmap to byte array
                    ByteArrayOutputStream stream = new ByteArrayOutputStream();
                    bmap.compress(Bitmap.CompressFormat.JPEG, 20, stream);
                    byte imageInByte[] = stream.toByteArray();

                    //insert the picture into database
                    Log.d("Insert: ", ""+item_id);
                    Picture tmp = new Picture(imageInByte,item_id);
                    long pic_id = db.addPicture(tmp);
                    pics.add(pic_id);
                    ////////////////////////////////////////////////////////////
                    byte[] outImage = imageInByte;
                    System.out.println("length of the image: " + outImage.length);

                    BitmapFactory.Options options = new BitmapFactory.Options();
                    options.inJustDecodeBounds = true;
                    BitmapFactory.decodeByteArray(outImage, 0, outImage.length, options);
                    System.out.println("height of bitmap: " + options.outHeight);
                    System.out.println("width of bitmap: " + options.outWidth);

                    // Calculate inSampleSize
                    options.inSampleSize = calculateInSampleSize(options, 200, 200);

                    // Decode bitmap with inSampleSize set
                    options.inJustDecodeBounds = false;

                    Bitmap bitmap = BitmapFactory.decodeByteArray(outImage , 0, outImage.length, options);
                    FileOutputStream out = null;
                    out  = new FileOutputStream(file);
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
                    ////////////////////////////////////////////////////////////
                    //to file
//                    bmap = MediaStore.Images.Media.getBitmap
//                            (this.getContentResolver(), mImageCaptureUri);
//
//                    try {
//                        FileOutputStream fos = openFileOutput(
//                                getString(R.string.itme_tmp_image), MODE_PRIVATE);
//                        bmap.compress(Bitmap.CompressFormat.JPEG, 90, fos);
//                        fos.flush();
//                        fos.close();
//                        uploadFile(uploadFilePath + "" + uploadFileName);
//
//                    } catch (Exception e) {
//                        e.printStackTrace();
//                    }

//                    dialog = ProgressDialog.show(GalleryActivity.this, "", "Uploading file...", true);
//
//                    new Thread(new Runnable() {
//                        public void run() {
//                            runOnUiThread(new Runnable() {
//                                public void run() {
////                                    messageText.setText("uploading started.....");
//                                }
//                            });
//
//                            uploadFile(uploadFilePath + "" + uploadFileName);
//
//                        }
//                    }).start();

//                    dialog = ProgressDialog.show(GalleryActivity.this, "", "Uploading file...", true);
//
//                    Log.d("URL:",uploadFilePath+ "" + uploadFileName);
//                    Log.d("URL",file.getAbsolutePath());
//                    uploadFile(uploadFilePath + "" + uploadFileName);

                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }

                break;
            case REQUEST_CODE:
                switch (resultCode) {
                    case Activity.RESULT_OK:
                        //data.setClass(this, CaptureResultActivity.class);
                        //startActivity(data);
                        edittext.setText(data.getStringExtra(Intents.Scan.RESULT));
                        //tvResultFormat.setText(data.getStringExtra(Intents.Scan.RESULT_FORMAT));
                        //tvUri.setText(data.toUri(data.getFlags()));
                        break;
                    default:
                        break;
                }
        }

    }

    public static int calculateInSampleSize(
            BitmapFactory.Options options, int reqWidth, int reqHeight) {
        // Raw height and width of image
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {

            final int halfHeight = height / 2;
            final int halfWidth = width / 2;

            // Calculate the largest inSampleSize value that is a power of 2 and keeps both
            // height and width larger than the requested height and width.
            while ((halfHeight / inSampleSize) > reqHeight
                    && (halfWidth / inSampleSize) > reqWidth) {
                inSampleSize *= 2;
            }
        }

        return inSampleSize;
    }

    @Override
    public void onResume() {
        super.onResume();

        final List<Picture> values = db.getAllPicturesForThisItem(item_id);
        adapter.clear();
        adapter.addAll(values);
        adapter.notifyDataSetChanged();
    }

    public void onSaveClicked(View v) throws IOException {
        if(ProfileActivity.myUserId != -1) {
            Toast.makeText(this, "User not registered", Toast.LENGTH_SHORT).show();
            finish();
        }
        upLoadPics();
        //ItemEntry entry = edb.getItemEntryById(item_id);
        edit_name = (EditText)findViewById(R.id.edit_name);
        edit_description = (EditText)findViewById(R.id.edit_description);
        edit_spinner = (Spinner)findViewById(R.id.input_spinner);
        edit_price = (EditText)findViewById(R.id.edit_price);
        edit_barcode = (EditText)findViewById(R.id.edit_barcode);
        edit_radiobutton = (RadioGroup) findViewById(R.id.radioGroup);
        priceview = (TextView)findViewById(R.id.comparePrice);

        itemEntry.setName(edit_name.getText().toString());
        if(edit_price.getText().toString()!=null&&edit_price.getText().toString().length()!=0)
        itemEntry.setPrice(Double.parseDouble(edit_price.getText().toString()));
        if(edit_spinner.getSelectedItemPosition()==0)
            itemEntry.setCategory(6);
        else
            itemEntry.setCategory(edit_spinner.getSelectedItemPosition());
        itemEntry.setDescription(edit_description.getText().toString());
        if(edit_barcode.getText().toString()!=null&&edit_barcode.getText().toString().length()!=0)
            itemEntry.setBarcode(Long.parseLong(edit_barcode.getText().toString()));
        itemEntry.setStatus(edit_radiobutton.indexOfChild(findViewById(edit_radiobutton.getCheckedRadioButtonId())));
        itemEntry.setMpicture(pics);
        itemEntry.setImage_urls(urls);
        Log.d("compare", "" + urls.get(0));
        Log.d("compare",""+ebayprice);
        itemEntry.setCompare_image(imageUrl);
        if(ebayprice!=null&&ebayprice.length()!=0)
            itemEntry.setCompare_price(Double.parseDouble(priceHelper(ebayprice)));
        itemEntry.setUserId(ProfileActivity.myUserId);
        itemEntry.setDatetime(Calendar.getInstance().getTimeInMillis());
        Log.d("Compare Price",""+itemEntry.getCompare_price());
        Log.d("SAVE","ItemEntry");
        Toast.makeText(this, "New item entry saved", Toast.LENGTH_SHORT).show();
        // Close the activity
        edb.addItemEntry(itemEntry);
        db.deleteAllPictures();

        //upload itemEntry
        JSONObject json = itemEntry.getJSONObject();
        String out = json.toString();
        Log.d("", "send(): " + out);
        sendItemToServer(out);
        finish();
    }

    public String priceHelper(String s){
        StringBuffer sb = new StringBuffer();
        for(int i=0;i<s.length();i++){
           if(s.charAt(i)>='0'&&s.charAt(i)<='9'||s.charAt(i)=='.')
               sb.append(s.charAt(i));
        }
        System.out.println(sb.toString());
        return sb.toString();
    }

    public void onCancelClicked(View v){

        db.deleteAllPictures();
        finish();
    }

    public void upLoadPics(){
        dialog = ProgressDialog.show(GalleryActivity.this, "", "Uploading file...", true);

        new Thread(new Runnable() {
            public void run() {
                runOnUiThread(new Runnable() {
                    public void run() {
//                                    messageText.setText("uploading started.....");
                    }
                });
                for(String name:url_names)
                    uploadFile(uploadFilePath + "" + name);

            }
        }).start();

    }

    public int uploadFile(String sourceFileUri) {


        String fileName = sourceFileUri;

        HttpURLConnection conn = null;
        DataOutputStream dos = null;
        String lineEnd = "\r\n";
        String twoHyphens = "--";
        String boundary = "*****";
        int bytesRead, bytesAvailable, bufferSize;
        byte[] buffer;
        int maxBufferSize = 1 * 1024 * 1024;
        File sourceFile = new File(sourceFileUri);

        if (!sourceFile.isFile()) {

            dialog.dismiss();

            Log.e("uploadFile", "Source File not exist :"
                    +sourceFileUri);

            runOnUiThread(new Runnable() {
                public void run() {
                    //messageText.setText("Source File not exist :"
                    // +uploadFilePath + "" + uploadFileName);
                }
            });

            return 0;

        }
        else
        {
            Log.d("else_serverresponscode",""+serverResponseCode);
            try {
                Log.d("try_serverresponscode",""+serverResponseCode);
                // open a URL connection to the Servlet
                FileInputStream fileInputStream = new FileInputStream(sourceFile);
                URL url = new URL(upLoadServerUri);

                // Open a HTTP  connection to  the URL
                conn = (HttpURLConnection) url.openConnection();
                Log.d("serve_after_openConnection",""+serverResponseCode);
                conn.setDoInput(true); // Allow Inputs
                conn.setDoOutput(true); // Allow Outputs
                conn.setUseCaches(false); // Don't use a Cached Copy
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Connection", "Keep-Alive");
                conn.setRequestProperty("ENCTYPE", "multipart/form-data");
                conn.setRequestProperty("Content-Type", "multipart/form-data;boundary=" + boundary);
                conn.setRequestProperty("uploaded_file", fileName);

                Log.d("serve_after_setConnection",""+serverResponseCode);

                dos = new DataOutputStream(conn.getOutputStream());

                dos.writeBytes(twoHyphens + boundary + lineEnd);
                dos.writeBytes("Content-Disposition: form-data; name=\"uploaded_file\";filename=\""
                        + fileName + "\"" + lineEnd);

                dos.writeBytes(lineEnd);

                Log.d("serve_after_lineend",""+serverResponseCode);

                // create a buffer of  maximum size
                bytesAvailable = fileInputStream.available();

                bufferSize = Math.min(bytesAvailable, maxBufferSize);
                buffer = new byte[bufferSize];

                // read file and write it into form...
                bytesRead = fileInputStream.read(buffer, 0, bufferSize);

                Log.d("serve_before_while",""+serverResponseCode);

                while (bytesRead > 0) {

                    dos.write(buffer, 0, bufferSize);
                    bytesAvailable = fileInputStream.available();
                    bufferSize = Math.min(bytesAvailable, maxBufferSize);
                    bytesRead = fileInputStream.read(buffer, 0, bufferSize);

                }

                // send multipart form data necesssary after file data...
                dos.writeBytes(lineEnd);
                dos.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);

                Log.d("server_before_getResponseCode",""+serverResponseCode);

                // Responses from the server (code and message)
                serverResponseCode = conn.getResponseCode();
                String serverResponseMessage = conn.getResponseMessage();
                Log.d("serverresponscode",""+serverResponseCode);
                Log.d("uploadFile", "HTTP Response is : "
                        + serverResponseMessage + ": " + serverResponseCode);

                if(serverResponseCode == 200){

                    runOnUiThread(new Runnable() {
                        public void run() {

                            String msg = "File Upload Completed.\n\n See uploaded file here : \n\n"
                                    +" http://www.androidexample.com/media/uploads/"
                                    +uploadFileName;

                            //messageText.setText(msg);
                            Toast.makeText(GalleryActivity.this, "File Upload Complete.",
                                    Toast.LENGTH_SHORT).show();
                        }
                    });
                }

                //close the streams //
                fileInputStream.close();
                dos.flush();
                dos.close();

            } catch (MalformedURLException ex) {

                dialog.dismiss();
                ex.printStackTrace();

                runOnUiThread(new Runnable() {
                    public void run() {
                        // messageText.setText("MalformedURLException Exception : check script url.");
                        Toast.makeText(GalleryActivity.this, "MalformedURLException",
                                Toast.LENGTH_SHORT).show();
                    }
                });

                Log.e("Upload file to server", "error: " + ex.getMessage(), ex);
            } catch (Exception e) {

                dialog.dismiss();
                e.printStackTrace();

                runOnUiThread(new Runnable() {
                    public void run() {
                        //  messageText.setText("Got Exception : see logcat ");
                        Toast.makeText(GalleryActivity.this, "Got Exception : see logcat ",
                                Toast.LENGTH_SHORT).show();
                    }
                });
                Log.e("Upload file to server Exception", "Exception : "
                        + e.getMessage(), e);
            }
            dialog.dismiss();
            return serverResponseCode;

        } // End else block
    }

    //********************************  Webview  *******************************//
    private class WebBrowser extends WebViewClient {

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            currentUrl=url;
            System.out.println(currentUrl);
            return true;
        }
    }

    public void onSearchClicked(View v) {
        //String url = "https://www.google.com/search?q="+"ebay+"+edittext.getText();
        String url = "http://www.ebay.com/sch/"+edittext.getText();
        webView.loadUrl(url);
    }

    public void onGetcontentClicked(View v) {
        //String siteUrl = "http://www.amazon.com/gp/aw/d/098478280X/ref=mp_s_a_1_1?qid=1425762862&sr=1-1";
        String siteUrl = currentUrl;
        ( new ParseURL() ).execute(new String[]{siteUrl});
        if(imageUrl != null) {
            System.out.println("imageuri is " + imageUrl);
            //imageview.setImageDrawable(MainActivity.LoadImageFromWebOperations(imageUrl));
            new LoadImage().execute(imageUrl);
            priceview.setText(ebayprice);
            generateLayout.setVisibility(LinearLayout.VISIBLE);
        }

    }
    private class ParseURL extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... strings) {
            StringBuffer buffer = new StringBuffer();
            boolean flag = true;

            try {
                Log.d("JSwa", "Connecting to [" + strings[0] + "]");
                Document doc  = Jsoup.connect(strings[0]).get();
                //System.out.println(doc);
                Log.d("JSwa", "Connected to ["+strings[0]+"]");
                // Get document (HTML page) title
                String title = doc.title();
                Log.d("JSwA", "Title ["+title+"]");
                buffer.append("Title: " + title + "\r\n");

                // Get meta info
                Elements metaElems = doc.select("meta");
                buffer.append("META DATA\r\n");
                for (Element metaElem : metaElems) {
                    String name = metaElem.attr("name");
                    String content = metaElem.attr("content");
                    buffer.append("name ["+name+"] - content ["+content+"] \r\n");
                }

//
//                Elements topicList = doc.select("h2.topic");
//                buffer.append("Topic list\r\n");
//                for (Element topic : topicList) {
//                    String data = topic.text();
//
//                    buffer.append("Data ["+data+"] \r\n");
//                }

//                Elements imgs = doc.getElementsByTag("img");
//
//                System.out.println("Total Links :"+imgs.size());
//
//                for (Element img : imgs) {
//                    //System.out.println(" * image: src :"+ img.attr("abs:src"));
//                    Pattern p = Pattern.compile("http://ecx.*");
//                    Matcher m = p.matcher(img.attr("abs:src"));
//                    if(m.matches() && flag) {
//                        flag = false;
//                        System.out.println("matches * image: src :"+ img.attr("abs:src"));
//                        imageUrl=img.attr("abs:src").toString();
//                    }
//                }

                Elements imgs = doc.getElementsByTag("img");

                System.out.println("Total Links :"+imgs.size());

                for (Element img : imgs) {
                    //System.out.println(" * image: src :"+ img.attr("abs:src"));
                    Pattern p = Pattern.compile("http://i.ebayimg.*");
                    Matcher m = p.matcher(img.attr("abs:src"));
                    if(m.matches() && flag) {
                        flag = false;
                        System.out.println("matches * image: src :"+ img.attr("abs:src"));
                        imageUrl=img.attr("abs:src").toString();
                    }
                }

                Elements priceElements = doc.select("div[class=bigPrice blue]");
                if(priceElements.size() >=1) {
                    String price = priceElements.get(0).text();
                    System.out.println("pricetest is "+price);
                }


                Elements priceElements2 = doc.select("div[class=price]");
                if(priceElements.size() >=1) {
                    String price2 = priceElements.get(0).text();
                    System.out.println("pricetest is " + price2);
                    ebayprice = price2;
                }
//                Elements priceElements2 = doc.select("span[class=a-color-price]");
//                String price2 = priceElements2.get(0).text();
//                System.out.println("price2test is "+price2);

            }
            catch(Throwable t) {
                t.printStackTrace();
            }
            System.out.println("test "+buffer.toString());
            return buffer.toString();
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
        }
    }

    public static Drawable LoadImageFromWebOperations(String url) {
        try {
            InputStream is = (InputStream) new URL(url).getContent();
            Drawable d = Drawable.createFromStream(is, "src name");
            return d;
        } catch (Exception e) {
            return null;
        }
    }

    private class LoadImage extends AsyncTask<String, String, Bitmap> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(GalleryActivity.this);
            pDialog.setMessage("Loading Image ....");
            pDialog.show();
        }
        protected Bitmap doInBackground(String... args) {
            try {
                bitmap = BitmapFactory.decodeStream((InputStream) new URL(args[0]).getContent());
            } catch (Exception e) {
                e.printStackTrace();
            }
            return bitmap;
        }
        protected void onPostExecute(Bitmap image) {
            if(image != null){
                imageview.setImageBitmap(image);
                pDialog.dismiss();
            }else{
                pDialog.dismiss();
                Toast.makeText(GalleryActivity.this, "Image Does Not exist or Network Error", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void sendItemToServer(String data) {
        new AsyncTask<String, Void, String>() {
            @Override
            protected String doInBackground(String... arg0) {
                String url = getString(R.string.server_addr) + "/postItem.do";
                //String url = getString(R.string.server_addr) + "/post.do";
                String res = "";
                Map<String, String> params = new HashMap<String, String>();
                params.put("data", arg0[0]);
                Log.d("data", arg0[0]);
                //params.put("from", "phone");
                try {
                    //res = ServerUtilities.post(url, params, "application/json");
                    res = ServerUtilities.post(url, params);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
                return res;
            }

            @Override
            protected void onPostExecute(String res) {
                Log.d("", "sendChatToServer: res = " + res);
                //mPostText.setText("");
                //refreshPostHistory();
            }
        }.execute(data);
    }
}