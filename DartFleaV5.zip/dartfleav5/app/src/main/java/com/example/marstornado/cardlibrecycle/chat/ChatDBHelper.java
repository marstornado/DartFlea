package com.example.marstornado.cardlibrecycle.chat;

/**
 * Created by huanlu on 2/3/15.
 */

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class ChatDBHelper extends SQLiteOpenHelper {

    private static final String TAG = "ChatDBHelper: ";

    // All Static variables
// Database Version
    private static final int DATABASE_VERSION = 1;

    // Database Name
    private static final String DATABASE_NAME = "chats.db";

    // Contacts table name
    private static final String TABLE_CHAT = "chats";

    // Contacts Table Columns names
    private static final String KEY_ID = "id";
    private static final String KEY_FROM = "mFrom";
    private static final String KEY_TO = "mTo";
    private static final String KEY_DATE_TIME = "mTimeInMillis";
    private static final String KEY_CONTENT = "mContent";

    private String[] allColumns = { KEY_ID, KEY_FROM, KEY_TO, KEY_DATE_TIME, KEY_CONTENT };

    public ChatDBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Creating Tables
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_CHATS_TABLE = "CREATE TABLE IF NOT EXISTS " + TABLE_CHAT + "("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + KEY_FROM + " INTEGER NOT NULL, "
                + KEY_TO + " INTEGER NOT NULL, "
                + KEY_DATE_TIME + " DATETIME NOT NULL, "
                + KEY_CONTENT + " TEXT " + ");";
        db.execSQL(CREATE_CHATS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.w(ChatDBHelper.class.getName(),
                "Upgrading database from version " + oldVersion + " to "
                        + newVersion + ", which will destroy all old data");
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CHAT);
        onCreate(db);
    }

    public long addChat(Chat chat) {
        Log.d(TAG, "addChat");
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_FROM, chat.getmFrom());
        values.put(KEY_TO, chat.getmTo());
        values.put(KEY_DATE_TIME, chat.getmTimeInMillis());
        values.put(KEY_CONTENT, chat.getmContent());

        long insertId = db.insert(TABLE_CHAT, null, values);
        db.close(); // Closing database connection
        return insertId;
    }

    public List<Chat> getAllChats(long user1, long user2) {
        Log.d(TAG, "getAllChats");
        List<Chat> chats = new ArrayList<Chat>();
        SQLiteDatabase db = this.getWritableDatabase();
        String whereClause = "( " + KEY_FROM + " = ? AND " + KEY_TO + " = ? ) " +
                "OR ( " + KEY_FROM + " = ? AND " + KEY_TO + " = ? )";
        Log.d(TAG, "whereClause: " + whereClause);

        String[] whereArgs = new String[] { user1 + "", user2 + "", user2 + "", user1 + ""};
        Log.d(TAG, "whereArgs: " + whereArgs);

        String orderBy = KEY_DATE_TIME;
        Log.d(TAG, "orderBy: " + orderBy);

        Cursor cursor = db.query(TABLE_CHAT,
                allColumns, whereClause, whereArgs, null, null, orderBy);

        Log.d(TAG, "row number in the cursor: " + cursor.getCount());

        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            Chat chat = cursorToChat(cursor);
            Log.d(TAG, "get entry = " + cursorToChat(cursor).toString());
            chats.add(chat);
            cursor.moveToNext();
        }

        // Make sure to close the cursor
        cursor.close();
        db.close();
        return chats;
    }

    public void deleteAllChatsWithContact(long contactUserId) {
        SQLiteDatabase db = this.getWritableDatabase();
        Log.d(TAG, "delete all chats with contactId = " + contactUserId);
        String selection = KEY_FROM + " = " + contactUserId + " OR " + KEY_TO + " = " + contactUserId;
        db.delete(TABLE_CHAT, selection, null);
        db.close();
    }

    public void deleteAllChats() {
        SQLiteDatabase db = this.getWritableDatabase();
        Log.d(TAG, "delete all");
        db.delete(TABLE_CHAT, null, null);
        db.close();
    }

    private Chat cursorToChat(Cursor cursor) {
        return new Chat(cursor.getLong(0), cursor.getLong(1),
                cursor.getLong(2), cursor.getLong(3), cursor.getString(4));
    }

//    public Picture getPictureById(long id) {
//        SQLiteDatabase db = this.getWritableDatabase();
//        Cursor cursor = db.query(TABLE_PICTURES,
//                allColumns, KEY_ID + " = " + id, null,
//                null, null, null);
//        cursor.moveToFirst();
//        Picture picture = cursorToPicture(cursor);
//
//        // Log the comment stored
//        Log.d(TAG, "get exercise entry = " + cursorToPicture(cursor).toString()
//                + " with ID = " + id);
//
//        cursor.close();
//        db.close();
//        return picture;
//    }
//
//    public void deletePictureById(long id) {
//        SQLiteDatabase db = this.getWritableDatabase();
//        Log.d(TAG, "delete picture = " + id);
//        db.delete(TABLE_PICTURES, KEY_ID + " = " + id, null);
//        db.close();
//    }
//
}
