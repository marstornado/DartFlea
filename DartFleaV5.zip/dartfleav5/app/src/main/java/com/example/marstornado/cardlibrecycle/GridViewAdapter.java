package com.example.marstornado.cardlibrecycle;

/**
 * Created by huanlu on 2/3/15.
 */

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;

import java.util.List;

public class GridViewAdapter extends ArrayAdapter {
    private Context context;
    //private int layoutResourceId;

    public GridViewAdapter(Context context, int layoutResourceId,
                           List<Picture> pictures) {
        super(context, layoutResourceId, pictures);
        //this.layoutResourceId = layoutResourceId;
        this.context = context;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Picture picture = (Picture)getItem(position);

        ImageView imageView = new ImageView(context);
        imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        //imageView.setLayoutParams(new GridView.LayoutParams(200, 200));


        byte[] outImage = picture.getImage();
        System.out.println("length of the image: " + outImage.length);

        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(outImage, 0, outImage.length, options);
        System.out.println("height of bitmap: " + options.outHeight);
        System.out.println("width of bitmap: " + options.outWidth);

        // Calculate inSampleSize
        options.inSampleSize = calculateInSampleSize(options, 200, 200);

        // Decode bitmap with inSampleSize set
        options.inJustDecodeBounds = false;

        Bitmap bitmap = BitmapFactory.decodeByteArray(outImage , 0, outImage.length, options);
        System.out.println("length of the bitmap: " + bitmap.getByteCount());

        imageView.setImageBitmap(bitmap);

        //return row;
        return imageView;
    }

    public static int calculateInSampleSize(
            BitmapFactory.Options options, int reqWidth, int reqHeight) {
        // Raw height and width of image
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {

            final int halfHeight = height / 2;
            final int halfWidth = width / 2;

            // Calculate the largest inSampleSize value that is a power of 2 and keeps both
            // height and width larger than the requested height and width.
            while ((halfHeight / inSampleSize) > reqHeight
                    && (halfWidth / inSampleSize) > reqWidth) {
                inSampleSize *= 2;
            }
        }

        return inSampleSize;
    }
}
