package com.example.marstornado.cardlibrecycle.chat;


public class Utility {
	public static String LogTag = "henrytest";
	public static String EXTRA_MSG = "extra_msg";

	
}
