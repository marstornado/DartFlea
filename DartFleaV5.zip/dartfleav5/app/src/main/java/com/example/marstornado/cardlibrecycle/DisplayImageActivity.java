package com.example.marstornado.cardlibrecycle;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.ByteArrayInputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;


public class DisplayImageActivity extends ActionBarActivity {

    public static final String DATE_TIME_FORMAT = "hh:mm:ss MMM dd yyyy";

    PictureDatabaseHelper db;
    ImageView mImageView;
    long id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_image);

        db = new PictureDatabaseHelper(this);

        id = getIntent().getLongExtra(GalleryActivity.EXTRA_PICTURE_ID, -1);
        Picture picture = db.getPictureById(id);

        mImageView = (ImageView)findViewById(R.id.imageDetail);
        byte[] outImage = picture.getImage();
        ByteArrayInputStream imageStream = new ByteArrayInputStream(outImage);
        Bitmap theImage = BitmapFactory.decodeStream(imageStream);
        mImageView.setImageBitmap(theImage);

//        SimpleDateFormat formatter = new SimpleDateFormat(DATE_TIME_FORMAT);
//        Calendar calendar = Calendar.getInstance();
//        calendar.setTimeInMillis(picture.getmDateTime());

//        TextView mTextView = (TextView) findViewById(R.id.textViewPictureInfo);
//        mTextView.setText(formatter.format(calendar.getTime()));
//
//        TextView gTextView = (TextView) findViewById(R.id.textViewGPSLocation);
//        String str="";
//        str =  "GPS:" + picture.getmLatitude() + "," + picture.getmLongitude();
//        gTextView.setText(str);
    }

    public void onDeletePictureClicked(View v){
        db.deletePictureById(id);
        finish();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_display_image, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
