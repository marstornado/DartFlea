package com.example.marstornado.cardlibrecycle.chat;

import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Chat {
    private final static String TAG = "Chat: ";

    public static final String FROM_USER_ID = "from_user_id";
    public static final String TO_USER_ID = "contact_user_id";
    public static final String DATE_TIME = "date_time";
    public static final String CONTENT = "content";

	private long id;
	private long mFrom;
	private long mTo;
    private long mTimeInMillis;
	private String mContent;

    public Chat(long mFrom, long mTo, String mContent) {
        this.mFrom = mFrom;
        this.mTo = mTo;
        this.mTimeInMillis = Calendar.getInstance().getTimeInMillis();
        this.mContent = mContent;
    }

    public Chat(long id, long mFrom, long mTo, long mTimeInMillis, String mContent) {
        this.id = id;
        this.mFrom = mFrom;
        this.mTo = mTo;
        this.mTimeInMillis = mTimeInMillis;
        this.mContent = mContent;
    }

    public Chat(JSONObject json){
        if(json == null){
            Log.d(TAG, "json object is null");
        }
        try {
            this.mFrom = json.getLong(FROM_USER_ID);
            this.mTo = json.getLong(TO_USER_ID);
            this.mTimeInMillis = json.getLong(DATE_TIME);
            this.mContent = json.getString(CONTENT);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getmFrom() {
        return mFrom;
    }

    public void setmFrom(long mFrom) {
        this.mFrom = mFrom;
    }

    public long getmTo() {
        return mTo;
    }

    public void setmTo(long mTo) {
        this.mTo = mTo;
    }

    public Calendar getmDateTime() {
        //public static final String DATE_TIME_FORMAT = "hh:mm:ss MMM dd yyyy";
        //SimpleDateFormat formatter = new SimpleDateFormat(DisplayEntryActivity.DATE_TIME_FORMAT);
        Calendar mDateTime = Calendar.getInstance();
        mDateTime.setTimeInMillis(mTimeInMillis);
        return mDateTime;
    }

    public void setmDateTime(Calendar mDateTime) {
        this.mTimeInMillis = mDateTime.getTimeInMillis();
    }

    public long getmTimeInMillis() {
        return mTimeInMillis;
    }

    public void setmTimeInMillis(long mTimeInMillis) {
        this.mTimeInMillis = mTimeInMillis;
    }

    public String getmContent() {
        return mContent;
    }

    public void setmContent(String mContent) {
        this.mContent = mContent;
    }

    public String toString(){
        SimpleDateFormat formatter = new SimpleDateFormat("hh:mm:ss MMM dd yyyy");
        String time = formatter.format(getmDateTime().getTime());
        return "id = " + id + ", from = " + mFrom + ", to = " + mTo + ", time = "
                + time + ", content = " + mContent;
    }
}
