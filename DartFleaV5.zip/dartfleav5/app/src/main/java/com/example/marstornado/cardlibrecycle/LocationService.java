package com.example.marstornado.cardlibrecycle;

/**
 * Created by zhenma on 3/1/15.
 */
public class LocationService {

}
