package com.example.marstornado.cardlibrecycle.chat;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.marstornado.cardlibrecycle.R;

import java.text.SimpleDateFormat;
import java.util.List;

/**
 * Created by huanlu on 3/7/15.
 */
public class ChatAdapter extends BaseAdapter {
    private static final String TAG = "ChatAdapter";
    private static final String DATE_TIME_FORMAT = "hh:mm:ss MMM dd yyyy";
    private Context context = null;
    private List<Chat> chatList = null;
    private LayoutInflater inflater = null;
    private long myUserId;
    private int COME_MSG = 0;
    private int TO_MSG = 1;

    public ChatAdapter(Context context, List<Chat> chatList){
        this.context = context;
        this.chatList = chatList;
        myUserId = ((ChatActivity)context).getMyUserId();
        inflater = LayoutInflater.from(this.context);
    }

    @Override
    public int getCount() {
        return chatList.size();
    }

    @Override
    public Object getItem(int position) {
        return chatList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemViewType(int position) {
        // 区别两种view的类型，标注两个不同的变量来分别表示各自的类型
        Chat chat = chatList.get(position);
        if (chat.getmFrom() != myUserId)
        {
            return COME_MSG;
        }else{
            return TO_MSG;
        }
    }

    @Override
    public int getViewTypeCount() {
        // 这个方法默认返回1，如果希望listview的item都是一样的就返回1，我们这里有两种风格，返回2
        return 2;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ChatHolder chatHolder = null;
        if (convertView == null) {
            chatHolder = new ChatHolder();
            if (chatList.get(position).getmFrom() != myUserId) {
                convertView = inflater.inflate(R.layout.chat_from_item, null);
            }else {
                convertView = inflater.inflate(R.layout.chat_to_item, null);
            }
            chatHolder.timeTextView = (TextView) convertView.findViewById(R.id.tv_time);
            chatHolder.contentTextView = (TextView) convertView.findViewById(R.id.tv_content);
            chatHolder.userImageView = (ImageView) convertView.findViewById(R.id.iv_user_image);
            convertView.setTag(chatHolder);
        }else {
            chatHolder = (ChatHolder)convertView.getTag();
        }

        Log.d(TAG, "getView: mfrom = " + chatList.get(position).getmFrom() + ", myUserId = " + myUserId);
        SimpleDateFormat formatter = new SimpleDateFormat(DATE_TIME_FORMAT);
        chatHolder.timeTextView.setText(formatter.format(chatList.get(position).getmDateTime().getTime()));
        chatHolder.contentTextView.setText(chatList.get(position).getmContent());
//        if(chatList.get(position).getmFrom() != myUserId)
//            chatHolder.userImageView.setImageResource(R.drawable.emma_watson);

        return convertView;
    }

    private class ChatHolder{
        private TextView timeTextView;
        private ImageView userImageView;
        private TextView contentTextView;
    }

}