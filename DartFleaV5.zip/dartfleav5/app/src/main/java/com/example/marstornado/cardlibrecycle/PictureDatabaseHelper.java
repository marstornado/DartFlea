package com.example.marstornado.cardlibrecycle;

/**
 * Created by huanlu on 2/3/15.
 */

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class PictureDatabaseHelper extends SQLiteOpenHelper {

    private static final String TAG = "log_tag: ";

    // All Static variables
// Database Version
    private static final int DATABASE_VERSION = 1;

    // Database Name
    private static final String DATABASE_NAME = "pictures.db";

    // Contacts table name
    private static final String TABLE_PICTURES = "pictures";

    // Contacts Table Columns names
    private static final String KEY_ID = "_id";
    private static final String KEY_IMAGE = "mImage";
    private static final String KEY_ITEMID = "mItemId";

    private String[] allColumns = { KEY_ID,
            KEY_IMAGE,KEY_ITEMID };

    public PictureDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Creating Tables
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_CONTACTS_TABLE = "CREATE TABLE IF NOT EXISTS " + TABLE_PICTURES + "("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + KEY_IMAGE + " BLOB, "
                + KEY_ITEMID + " FLOAT "
                + ");";
        db.execSQL(CREATE_CONTACTS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.w(PictureDatabaseHelper.class.getName(),
                "Upgrading database from version " + oldVersion + " to "
                        + newVersion + ", which will destroy all old data");
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PICTURES);
        onCreate(db);
    }

    public long addPicture(Picture image) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_IMAGE, image.getImage());
        values.put(KEY_ITEMID, image.getItem_id());

        long insertId = db.insert(TABLE_PICTURES, null, values);
        db.close(); // Closing database connection
        return insertId;
    }

    public List<Picture> getAllPicturesForThisItem(long item_id) {
        List<Picture> pictures = new ArrayList<Picture>();
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.query(TABLE_PICTURES,
                allColumns, null, null, null, null, null);


        Log.d(TAG, "row number in the cursor: " + cursor.getCount());

        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            Picture picture = cursorToPicture(cursor);
            Log.d(TAG, "get entry = " + cursorToPicture(cursor).toString());
            if(picture.getItem_id()==item_id) {
                Log.d(TAG,""+picture.getItem_id());
                pictures.add(picture);
            }
            cursor.moveToNext();
        }

        // Make sure to close the cursor
        cursor.close();
        db.close();
        return pictures;
    }

    public Picture getPictureById(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.query(TABLE_PICTURES,
                allColumns, KEY_ID + " = " + id, null,
                null, null, null);
        cursor.moveToFirst();
        Picture picture = cursorToPicture(cursor);

        // Log the comment stored
        Log.d(TAG, "get picture entry = " + cursorToPicture(cursor).toString()
                + " with ID = " + id);

        cursor.close();
        db.close();
        return picture;
    }

    public void deletePictureById(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        Log.d(TAG, "delete picture = " + id);
        db.delete(TABLE_PICTURES, KEY_ID + " = " + id, null);
        db.close();
    }

    public void deleteAllPictures() {
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.query(TABLE_PICTURES,
                allColumns, null, null, null, null, null);


        Log.d(TAG, "delete picture item: " + cursor.getCount());

        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            Picture picture = cursorToPicture(cursor);
            Log.d(TAG, "delete picture = " + cursorToPicture(cursor).toString());
            deletePictureById(picture.getId());

            cursor.moveToNext();
        }

        // Make sure to close the cursor
        cursor.close();
        db.close();

		Log.d(TAG, "delete all = ");

		//db.delete(TABLE_PICTURES, null, null);
        db.close();
	}

    private Picture cursorToPicture(Cursor cursor) {
        Picture picture = new Picture();

        picture.setId(cursor.getLong(0));
        picture.setImage(cursor.getBlob(1));
        picture.setItem_id(cursor.getLong(2));

        return picture;
    }
}
