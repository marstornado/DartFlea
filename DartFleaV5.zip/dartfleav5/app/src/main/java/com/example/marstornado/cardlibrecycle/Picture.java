package com.example.marstornado.cardlibrecycle;

import java.util.Calendar;

/**
 * Created by huanlu on 2/3/15.
 */

public class Picture {

    // private variables
    private long id;
    byte[] image;
    private long item_id;

    // Empty constructor
    public Picture() {
        this.image = null;
    }

    public Picture(byte[] image,long item_id) {
        this.item_id = item_id;
        this.image = image;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }


    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }

    public long getItem_id() {
        return item_id;
    }

    public void setItem_id(long item_id) {
        this.item_id = item_id;
    }
}