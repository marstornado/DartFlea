package com.example.marstornado.cardlibrecycle;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by menglingli on 3/6/15.
 */
public class EntryDatabaseHelper extends SQLiteOpenHelper {

    PictureDatabaseHelper db;

    private static final String TAG = "Entry DB";

    // All Static variables
// Database Version
    private static final int DATABASE_VERSION = 1;

    // Database Name
    private static final String DATABASE_NAME = "entry.db";

    // Contacts table name
    private static final String TABLE_ENTRIES = "entries";

    // Contacts Table Columns names

    private static final String KEY_ID = "_id";
    private static final String KEY_NAME = "mName";
    private static final String KEY_PRICE = "mPrice";
    private static final String KEY_DESCRIPTION = "mDescription";
    private static final String KEY_STATUS = "mStatus";
    private static final String KEY_CATEGORY= "mCategory";
    private static final String KEY_BARCODE = "mBarcode";
    private static final String KEY_DATETIME = "mDateTime";
    private static final String KEY_PICTURES = "mPicture";
    private static final String KEY_URLS = "mUrls";
    private static final String KEY_USERID = "mUserId";
    private static final String KEY_COMPARE_IMAGE = "mCompareImage";
    private static final String KEY_COMPARE_PRICE = "mComparePrice";


    private String[] allColumns = { KEY_ID, KEY_NAME,
            KEY_PRICE, KEY_DESCRIPTION, KEY_STATUS,KEY_CATEGORY,KEY_BARCODE,KEY_DATETIME,KEY_PICTURES,KEY_URLS
            ,KEY_USERID,KEY_COMPARE_IMAGE,KEY_COMPARE_PRICE};

    public EntryDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Creating Tables
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_CONTACTS_TABLE = "CREATE TABLE IF NOT EXISTS " + TABLE_ENTRIES + "("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + KEY_NAME + " TEXT, "
                + KEY_PRICE + " FLOAT, "
                + KEY_DESCRIPTION + " FLOAT, "
                + KEY_STATUS + " FLOAT, "
                + KEY_CATEGORY + " FLOAT, "
                + KEY_BARCODE + " FLOAT, "
                + KEY_DATETIME + " FLOAT, "
                + KEY_PICTURES + " TEXT, "
                + KEY_URLS + " TEXT, "
                + KEY_USERID + " FLOAT, "
                + KEY_COMPARE_IMAGE + " TEXT, "
                + KEY_COMPARE_PRICE + " TEXT "
                + ");";
        db.execSQL(CREATE_CONTACTS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.w(PictureDatabaseHelper.class.getName(),
                "Upgrading database from version " + oldVersion + " to "
                        + newVersion + ", which will destroy all old data");
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ENTRIES);
        onCreate(db);
    }

    public long addItemEntry(ItemEntry entry) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_NAME, entry.getName());
        values.put(KEY_PRICE, entry.getPrice());
        values.put(KEY_DESCRIPTION, entry.getDescription());
        values.put(KEY_STATUS, entry.getStatus());
        values.put(KEY_CATEGORY,entry.getCategory());
        values.put(KEY_BARCODE,entry.getBarcode());
        values.put(KEY_DATETIME,entry.getDatetime());

        if(entry.getMpicture()!=null){
            ArrayList<Long> arrayList = entry.getMpicture();
            StringBuffer sb =  new StringBuffer();
            for(int i=0;i<arrayList.size();i++){
                sb.append(String.valueOf(arrayList.get(i))).append(',');
            }
            Log.d(TAG,"mPicture:"+sb.toString());
            values.put(KEY_PICTURES,sb.toString());
        }

        if(entry.getImage_urls()!=null){
            ArrayList<String> arrayList = entry.getImage_urls();
            StringBuffer sb =  new StringBuffer();
            for(int i=0;i<arrayList.size();i++){
                sb.append(arrayList.get(i)).append(',');
            }
            Log.d(TAG,"ADD NEW "+entry.getId()+" mUrls:"+sb.toString());
            values.put(KEY_URLS,sb.toString());
        }

        values.put(KEY_USERID,entry.getUserId());
        values.put(KEY_COMPARE_IMAGE,entry.getCompare_image());
        values.put(KEY_COMPARE_PRICE,entry.getCompare_price());

        long insertId = db.insert(TABLE_ENTRIES, null, values);
        db.close(); // Closing database connection
        return insertId;
    }

    public void updateItemEntry(ItemEntry entry) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_NAME, entry.getName());
        values.put(KEY_PRICE, entry.getPrice());
        values.put(KEY_DESCRIPTION, entry.getDescription());
        values.put(KEY_STATUS, entry.getStatus());
        values.put(KEY_CATEGORY,entry.getCategory());
        values.put(KEY_BARCODE,entry.getBarcode());
        values.put(KEY_DATETIME,entry.getDatetime());

        if(entry.getMpicture()!=null){
            ArrayList<Long> arrayList = entry.getMpicture();
            StringBuffer sb =  new StringBuffer();
            for(int i=0;i<arrayList.size();i++){
                sb.append(String.valueOf(arrayList.get(i))).append(',');
            }
            Log.d(TAG,"mPicture:"+sb.toString());
            values.put(KEY_PICTURES,sb.toString());
        }

        if(entry.getImage_urls()!=null){
            ArrayList<String> arrayList = entry.getImage_urls();
            StringBuffer sb =  new StringBuffer();
            for(int i=0;i<arrayList.size();i++){
                sb.append(arrayList.get(i)).append(',');
            }
            Log.d(TAG,"UPDATE "+entry.getId()+" mUrls:"+sb.toString());
            values.put(KEY_URLS,sb.toString());
        }

        db.update(TABLE_ENTRIES, values, KEY_ID + "=" + entry.getId(), null);
        Log.d(TAG,"updates successfully");
        db.close(); // Closing database connection
    }

    public List<ItemEntry> getAllItemEntriesByCategory(int category) {
        if(category==0)
                return getAllItemEntries();
        List<ItemEntry> itemEntries = new ArrayList<ItemEntry>();
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.query(TABLE_ENTRIES,
                allColumns, null, null, null, null, null);

        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            ItemEntry entry = cursorToItemEntry(cursor);
            Log.d(TAG, "get entry = " + cursorToItemEntry(cursor).toString());
            if(category==entry.getCategory())
                itemEntries.add(entry);
            cursor.moveToNext();
        }

        // Make sure to close the cursor
        cursor.close();
        db.close();
        return itemEntries;
    }

    public List<ItemEntry> getAllItemEntries() {
        List<ItemEntry> itemEntries = new ArrayList<ItemEntry>();
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.query(TABLE_ENTRIES,
                allColumns, null, null, null, null, null);


        Log.d(TAG, "row number in the cursor: " + cursor.getCount());

        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            ItemEntry entry = cursorToItemEntry(cursor);
            Log.d(TAG, "get entry = " + cursorToItemEntry(cursor).toString());
            itemEntries.add(entry);
            cursor.moveToNext();
        }

        // Make sure to close the cursor
        cursor.close();
        db.close();
        return itemEntries;
    }

    public ItemEntry getItemEntryById(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.query(TABLE_ENTRIES,
                allColumns, KEY_ID + " = " + id, null,
                null, null, null);
        cursor.moveToFirst();
        ItemEntry itementry = cursorToItemEntry(cursor);

        // Log the comment stored
        Log.d(TAG, "get exercise entry = " + cursorToItemEntry(cursor).toString()
                + " with ID = " + id);

        cursor.close();
        db.close();
        return itementry;
    }

    public void deleteItemEntryById(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        Log.d(TAG, "delete entry = " + id);
        db.delete(TABLE_ENTRIES, KEY_ID + " = " + id, null);
        db.close();
    }

    public void deleteAllItemEntries() {
        SQLiteDatabase db = this.getWritableDatabase();
        Log.d(TAG, "delete all = ");
        db.delete(TABLE_ENTRIES, null, null);
        db.close();
    }




    private ItemEntry cursorToItemEntry(Cursor cursor) {
        ItemEntry itemEntry = new ItemEntry();

        itemEntry.setId(cursor.getLong(0));
        itemEntry.setName(cursor.getString(1));
        itemEntry.setPrice(cursor.getDouble(2));
        itemEntry.setDescription(cursor.getString(3));
        itemEntry.setStatus(cursor.getInt(4));
        itemEntry.setCategory(cursor.getInt(5));
        itemEntry.setBarcode(cursor.getLong(6));
        itemEntry.setDatetime(cursor.getLong(7));

        String stream = cursor.getString(8);
        if(stream != null){
            String[] ss = stream.split(",");
            ArrayList<Long> list = new ArrayList<Long>();
            for(int i=0;i<ss.length;i++){
                if(ss[i]!=null&&ss[i].length()!=0) {
                    list.add(Long.parseLong(ss[i]));
                }
            }
            itemEntry.setMpicture(list);
        }

        String str = cursor.getString(9);
        if(str != null){
            String[] ss = str.split(",");
            ArrayList<String> list = new ArrayList<String>();
            for(int i=0;i<ss.length;i++){
                if(ss[i]!=null&&ss[i].length()!=0) {
                    list.add(ss[i]);
                }
            }
            itemEntry.setImage_urls(list);
        }

        itemEntry.setUserId(cursor.getLong(10));
        itemEntry.setCompare_image(cursor.getString(11));
        itemEntry.setCompare_price(cursor.getDouble(12));


        return itemEntry;
    }
}
