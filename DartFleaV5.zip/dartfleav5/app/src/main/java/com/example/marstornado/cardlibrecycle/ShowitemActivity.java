package com.example.marstornado.cardlibrecycle;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.marstornado.cardlibrecycle.chat.ChatActivity;

import java.io.InputStream;
import java.util.ArrayList;


public class ShowitemActivity extends Activity {

    private Intent intent;
    private ImageButton btn_contact = null;
    private long item_id;
    private ItemEntry itemEntry;

    private ActionBar mActionBar;
    EntryDatabaseHelper item_db;
    TextView edit_name;
    TextView edit_price;
    TextView edit_description;

    final String serverFilePath = "http://www.cs.dartmouth.edu/~marstornado/media/uploads/";
    private TextView compare_price;

    private long contactUserId = 1L;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_showitem);
        Intent intent = getIntent();
        item_id = intent.getLongExtra("item_id",0);
        Log.d("item_id",""+item_id);
        item_db = new EntryDatabaseHelper(this);
        itemEntry = item_db.getItemEntryById(item_id);
        contactUserId = itemEntry.getUserId();
//        pic_db = new PictureDatabaseHelper(this);
        ExpandableHeightGridView gridview = (ExpandableHeightGridView) findViewById(R.id.gridview);
        gridview.setExpanded(true);
        gridview.setAdapter(new ImageAdapter(this));

        gridview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
                Toast.makeText(ShowitemActivity.this, "" + position, Toast.LENGTH_SHORT).show();
            }
        });

        btn_contact = (ImageButton) findViewById(R.id.btn_contact);
        btn_contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(ShowitemActivity.this, ChatActivity.class);
                it.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
                it.putExtra(ChatActivity.CONTACT_USER_ID, contactUserId);
                startActivity(it);
            }
        });


        new DownloadImageTask((ImageView) findViewById(R.id.main_image))
                .execute(serverFilePath+itemEntry.getImage_urls().get(0));

        edit_name = (TextView) findViewById(R.id.name);
        edit_price = (TextView) findViewById(R.id.price);
        edit_description = (TextView) findViewById(R.id.textView);
        compare_price = (TextView)findViewById(R.id.comparePrice);


        if(itemEntry.getCompare_image()!=null&&itemEntry.getCompare_image().length()!=0) {
            new DownloadImageTask((ImageView) findViewById(R.id.compareImageview))
                    .execute(itemEntry.getCompare_image());
            compare_price.setText("$"+String.valueOf(itemEntry.getCompare_price()));

        }


        edit_name.setText(itemEntry.getName());
        edit_price.setText("$"+String.valueOf(itemEntry.getPrice()));
        edit_description.setText(itemEntry.getDescription());



        mActionBar = getActionBar();
        mActionBar.hide();
    }

    public class ImageAdapter extends BaseAdapter {
        private Context mContext;

        private String[] mThumbIds = setImages(itemEntry.getImage_urls());

        public ImageAdapter(Context c) {
            mContext = c;
        }

        public int getCount() {
            return mThumbIds.length;
        }

        public Object getItem(int position) {
            return null;
        }

        public long getItemId(int position) {
            return 0;
        }

        // create a new ImageView for each item referenced by the Adapter
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ImageView imageView;
            if (convertView == null) {  // if it's not recycled, initialize some attributes
                imageView = new ImageView(mContext);
                imageView.setLayoutParams(new GridView.LayoutParams(125, 125));
                imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                imageView.setPadding(8, 8, 8, 8);
            } else {
                imageView = (ImageView) convertView;
            }
            System.out.println(mThumbIds[position]);

            if(mThumbIds[position]!=null)
                new DownloadImageTask((ImageView) imageView)
                        .execute(mThumbIds[position]);


            return imageView;
        }
        // references to our images

    }

    private class DownloadImageTask extends AsyncTask<String, Void, Bitmap> {
        ImageView bmImage;

        public DownloadImageTask(ImageView bmImage) {
            this.bmImage = bmImage;
        }

        protected Bitmap doInBackground(String... urls) {
            String urldisplay = urls[0];
            Bitmap mIcon11 = null;
            try {
                InputStream in = new java.net.URL(urldisplay).openStream();
                mIcon11 = BitmapFactory.decodeStream(in);
            } catch (Exception e) {
                Log.e("Error", e.getMessage());
                e.printStackTrace();
            }
            return mIcon11;
        }

        protected void onPostExecute(Bitmap result) {
            bmImage.setImageBitmap(result);
        }
    }

    public String[] setImages(ArrayList<String> list){
        int cnt = list.size();
        String[] res = new String[cnt];
        for(int i=0;i<cnt;i++){
            res[i] = serverFilePath+list.get(i);

        }
        return res;
    }

    public void onCompareClick(View v){

//        intent = new Intent();
//        intent.setClass(this, MapsActivity.class);
//        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_showitem, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void onCommentClick(View view){
        Toast.makeText(ShowitemActivity.this," Comments posted ", Toast.LENGTH_SHORT).show();
    }
}
