package com.example.marstornado.cardlibrecycle;

import android.app.ActionBar;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.SpinnerAdapter;
import android.widget.Toast;

import com.example.marstornado.cardlibrecycle.chat.Chat;
import com.example.marstornado.cardlibrecycle.chat.ChatActivity;
import com.example.marstornado.cardlibrecycle.chat.ChatDBHelper;
import com.example.marstornado.cardlibrecycle.chat.ChatHeadService;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.gcm.GoogleCloudMessaging;
import com.melnykov.fab.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import it.gmariotti.cardslib.library.cards.actions.BaseSupplementalAction;
import it.gmariotti.cardslib.library.cards.actions.TextSupplementalAction;
import it.gmariotti.cardslib.library.cards.material.MaterialLargeImageCard;
import it.gmariotti.cardslib.library.internal.Card;
import it.gmariotti.cardslib.library.recyclerview.internal.CardArrayRecyclerViewAdapter;
import it.gmariotti.cardslib.library.recyclerview.view.CardRecyclerView;


public class MainActivity extends Activity {
    private final static String TAG = "MainActivity";
    public static final String PROPERTY_REG_ID = "Registration_id";
    private static final String PROPERTY_APP_VERSION = "appVersion";
    private final static int PLAY_SERVICES_RESOLUTION_REQUEST = 9000;

    private String SENDER_ID = "899868157206";
    private GoogleCloudMessaging gcm;
    public static String regid = "";


    private Context context;

    CardArrayRecyclerViewAdapter mCardArrayAdapter;
    ArrayList<Card> cards;
    private Intent intent;

    private ActionBar mActionBar;
    private float mActionBarHeight;
    private int overallXScrol = 0;
    private int total_num ;
    List<ItemEntry> all_entries;
    EntryDatabaseHelper item_db;
    int category;

    String[] piclist;
    final String serverFilePath = "http://www.cs.dartmouth.edu/~marstornado/media/uploads/";

    public static ArrayList<ItemEntry> itemList;

    private IntentFilter mMessageIntentFilter;
    private BroadcastReceiver mMessageUpdateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String json_string = intent.getStringExtra("json_string");
            Log.d(TAG, "BroadcastReceiver: json_string = " + json_string);
            itemList = new ArrayList<ItemEntry>();
            try{
                JSONObject json = new JSONObject(json_string);
                JSONArray array = json.getJSONArray("itemList");

                int size = array.length();
                for(int i=0; i<size; i++){
                    JSONObject obj = array.getJSONObject(i);
                    Log.d(TAG, "BroadcastReceiver: JSONObject = " + obj.toString());
                    ItemEntry item = new ItemEntry(obj);
                    Log.d(TAG, "item: " + item.toString());
                    itemList.add(item);
                    Log.d(TAG, "item: " + itemList.size());
                }

                item_db = new EntryDatabaseHelper(MainActivity.this);
                item_db.deleteAllItemEntries();
//        Log.d("size",""+itemList.size());
                if(itemList!=null&& itemList.size()!=0) {
                    //   Log.d("not null",""+itemList.size());
                    for (ItemEntry i : itemList) {
                        item_db.addItemEntry(i);
                    }
                }

                new LoaderAsyncTask().execute();
//                Chat chat = new Chat(json);
//                ChatDBHelper chatDB = new ChatDBHelper(context);
//                long id = chatDB.addChat(chat);
//                chat.setId(id);
//                Log.d(TAG, "chat = " + chat.toString());


            } catch (JSONException e){
                e.printStackTrace();
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        context = getApplicationContext();

        ProfileActivity.myUserId = getUserIdFromSharedPref();

        // Check device for Play Services APK. If check succeeds, proceed with
        // GCM registration.
        if (checkPlayServices()) {
            Log.d(TAG, "checkPlayServices succeed");
            gcm = GoogleCloudMessaging.getInstance(this);
            regid = getRegistrationId(context);
            if (regid.isEmpty()) {
                Log.d(TAG, "not registered, regid = " + regid);
                registerInBackground();
            } else { Log.d(TAG, "regid = " + regid); }
        } else {
            Log.d(TAG, "checkPlayServices failed");
        }

        mMessageIntentFilter = new IntentFilter();
        mMessageIntentFilter.addAction("GCM_DOWNLOAD");
        registerReceiver(mMessageUpdateReceiver, mMessageIntentFilter);

        testDownloadItemListFromServer();


        item_db = new EntryDatabaseHelper(this);
        item_db.deleteAllItemEntries();
//        Log.d("size",""+itemList.size());
        if(itemList!=null&& itemList.size()!=0) {
         //   Log.d("not null",""+itemList.size());
            for (ItemEntry i : itemList) {
                item_db.addItemEntry(i);
            }
        }


        // Adapter
        SpinnerAdapter adapter =
                ArrayAdapter.createFromResource(this, R.array.category_array,
                        android.R.layout.simple_spinner_dropdown_item);

// Callback
        ActionBar.OnNavigationListener callback = new ActionBar.OnNavigationListener() {

            String[] items = getResources().getStringArray(R.array.category_array); // List items from res

            @Override
            public boolean onNavigationItemSelected(int position, long id) {

                // Do stuff when navigation item is selected

                category = position;
                all_entries = item_db.getAllItemEntriesByCategory(category);
                total_num = all_entries.size();
                new LoaderAsyncTask().execute();
                return true;

            }

        };

// Action Bar
        ActionBar actions = getActionBar();
        actions.setNavigationMode(ActionBar.NAVIGATION_MODE_LIST);
        actions.setDisplayShowTitleEnabled(false);
        actions.setListNavigationCallbacks(adapter, callback);


        startService(new Intent(MainActivity.this, ChatHeadService.class));

//        all_entries = item_db.getAllItemEntriesByCategory(category);
//
//       total_num = all_entries.size();
        //Set the arrayAdapter
        cards = new ArrayList<Card>();

        mCardArrayAdapter = new CardArrayRecyclerViewAdapter(MainActivity.this, cards);

        //Staggered grid view
        CardRecyclerView mRecyclerView = (CardRecyclerView) MainActivity.this.findViewById(R.id.carddemo_recyclerview2);
        mRecyclerView.setHasFixedSize(false);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));

        //Set the empty view
        if (mRecyclerView != null) {
            mRecyclerView.setAdapter(mCardArrayAdapter);
        }
        intent = new Intent();
        //Load cards
        cards = initCard();
        ActionBar bar = getActionBar();
        bar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#FFFFFF")));
        //new LoaderAsyncTask().execute();
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.attachToRecyclerView(mRecyclerView);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent = new Intent();
                intent.setClass(MainActivity.this, GalleryActivity.class);
                Toast.makeText(MainActivity.this," Click on add ", Toast.LENGTH_SHORT).show();
                startActivity(intent);
            }
        });

        final TypedArray styledAttributes = getTheme().obtainStyledAttributes(
                new int[] { android.R.attr.actionBarSize });
        mActionBarHeight = styledAttributes.getDimension(0, 0);
        styledAttributes.recycle();
        mActionBar = getActionBar();
        //mActionBar.hide();
        mRecyclerView.setOnScrollListener(new CardRecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                overallXScrol = overallXScrol + dy;
                float y = overallXScrol;
                if (y >= mActionBarHeight && mActionBar.isShowing()) {
                    mActionBar.hide();
                } else if ( y==0 && !mActionBar.isShowing()) {
                    mActionBar.show();
                }
            }
        });



    }



    @Override
    protected void onResume() {
        registerReceiver(mMessageUpdateReceiver, mMessageIntentFilter);
        super.onResume();
        //updateAdapter(cards);
        mCardArrayAdapter.clear();
        new LoaderAsyncTask().execute();
    }

    @Override
    protected void onPause() {
        unregisterReceiver(mMessageUpdateReceiver);
        super.onPause();
        //updateAdapter(cards);

        new LoaderAsyncTask().execute();
    }

    private void testDownloadItemListFromServer(){
        JSONObject json = new JSONObject();
        try{
            json.put("regid", MainActivity.regid);
            json.put("userid", ProfileActivity.myUserId);
        }catch(Exception e){
            e.printStackTrace();
        }
        String out = json.toString();
        //Log.d(TAG, "testDownloadItemListFromServer(): " + MainActivity.regid);
        //downloadItemListFromServer(MainActivity.regid);
        downloadItemListFromServer(out);
    }

    private void downloadItemListFromServer(String data) {
        new AsyncTask<String, Void, String>() {
            @Override
            protected String doInBackground(String... arg0) {
                String url = getString(R.string.server_addr) + "/download.do";
                //String url = getString(R.string.server_addr) + "/post.do";
                String res = "";
                Map<String, String> params = new HashMap<String, String>();
                params.put("data", arg0[0]);
                Log.d("data", arg0[0]);
                //params.put("from", "phone");
                try {
                    //res = ServerUtilities.post(url, params, "application/json");
                    res = ServerUtilities.post(url, params);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
                return res;
            }

            @Override
            protected void onPostExecute(String res) {
                Log.d(TAG, "downloadItemListFromServer: res = " + res);
                //mPostText.setText("");
                //refreshPostHistory();
            }
        }.execute(data);
    }
    private Long getUserIdFromSharedPref(){
        // Load and update all profile views
        String key = getString(R.string.preference_private);
        SharedPreferences prefs = getSharedPreferences(key, MODE_PRIVATE);

        // Load myUserId
        key = getString(R.string.preference_user_id);
        return prefs.getLong(key, -1);
    }
    public static String getRegid(){
        return regid;
    }

    private void registerInBackground() {
        new AsyncTask<Void, Void, String>() {
            @Override
            protected String doInBackground(Void... params) {
                String msg = "";
                try {
                    if (gcm == null) {
                        gcm = GoogleCloudMessaging.getInstance(context);
                    }
                    regid = gcm.register(SENDER_ID);
                    msg = "Device registered, registration ID=" + regid;

                    // You should send the registration ID to your server over
                    // HTTP,
                    // so it can use GCM/HTTP or CCS to send messages to your
                    // app.
                    // The request to your server should be authenticated if
                    // your app
                    // is using accounts.
                    ServerUtilities.sendRegistrationIdToBackend(context, regid);

                    // For this demo: we don't need to send it because the
                    // device
                    // will send upstream messages to a server that echo back
                    // the
                    // message using the 'from' address in the message.

                    // Persist the regID - no need to register again.
                    storeRegistrationId(context, regid);
                } catch (IOException ex) {
                    msg = "Error :" + ex.getMessage();
                    // If there is an error, don't just keep trying to register.
                    // Require the user to click a button again, or perform
                    // exponential back-off.
                }
                return msg;
            }

            @Override
            protected void onPostExecute(String msg) {
                Log.i(TAG, "gcm register msg: " + msg);
            }
        }.execute(null, null, null);
    }

    /**
     * Check the device to make sure it has the Google Play Services APK. If it
     * doesn't, display a dialog that allows users to download the APK from the
     * Google Play Store or enable it in the device's system settings.
     */
    private boolean checkPlayServices() {
        int resultCode = GooglePlayServicesUtil
                .isGooglePlayServicesAvailable(this);
        if (resultCode != ConnectionResult.SUCCESS) {
            if (GooglePlayServicesUtil.isUserRecoverableError(resultCode)) {
                GooglePlayServicesUtil.getErrorDialog(resultCode, this,
                        PLAY_SERVICES_RESOLUTION_REQUEST).show();
            } else {
                finish();
            }
            return false;
        }
        return true;
    }

    private void storeRegistrationId(Context context, String regId) {
        final SharedPreferences prefs = getGCMPreferences(context);
        int appVersion = getAppVersion(context);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(PROPERTY_REG_ID, regId);
        editor.putInt(PROPERTY_APP_VERSION, appVersion);
        editor.commit();
    }

    private String getRegistrationId(Context context) {
        final SharedPreferences prefs = getGCMPreferences(context);
        String registrationId = prefs.getString(PROPERTY_REG_ID, "");
        if (registrationId.isEmpty()) {
            return "";
        }
        // Check if app was updated; if so, it must clear the registration ID
        // since the existing regID is not guaranteed to work with the new
        // app version.
        int registeredVersion = prefs.getInt(PROPERTY_APP_VERSION,
                Integer.MIN_VALUE);
        int currentVersion = getAppVersion(context);
        if (registeredVersion != currentVersion) {
            return "";
        }
        return registrationId;
    }

    private SharedPreferences getGCMPreferences(Context context) {
        // This sample app persists the registration ID in shared preferences,
        // but
        // how you store the regID in your app is up to you.
        return getSharedPreferences(MainActivity.class.getSimpleName(),
                Context.MODE_PRIVATE);
    }

    private static int getAppVersion(Context context) {
        try {
            PackageInfo packageInfo = context.getPackageManager()
                    .getPackageInfo(context.getPackageName(), 0);
            return packageInfo.versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            // should never happen
            throw new RuntimeException("Could not get package name: " + e);
        }
    }

    //-------------------------------------------------------------------------------------------------------------
    // Images loader
    //-------------------------------------------------------------------------------------------------------------

    /**
     * This method builds a simple list of cards
     */
    private ArrayList<Card> initCard() {

        //Init an array of Cards
        ArrayList<Card> cards = new ArrayList<Card>();
        piclist = new String[total_num];

        for (int i = 0; i < total_num; i++) {
//            Long main_image_id = all_entries.get(i).getMpicture().get(0);
    //        Picture main_image = pic_db.getPictureById(main_image_id);
           // piclist[i] = main_image.getImage();
            if(all_entries.get(i).getImage_urls().size()==0)    continue;
            piclist[i] = serverFilePath+all_entries.get(i).getImage_urls().get(0);

            ArrayList<BaseSupplementalAction> actions = new ArrayList<BaseSupplementalAction>();

            // Set supplemental actions
            //TextSupplementalAction t1 = new TextSupplementalAction(MainActivity.this, R.id.text1);
//            t1.setOnActionClickListener(new BaseSupplementalAction.OnActionClickListener() {
//                @Override
//                public void onClick(Card card, View view) {
//                    Toast.makeText(MainActivity.this," Click on Text SHARE "+card.getTitle(),Toast.LENGTH_SHORT).show();
//                }
//            });
//            actions.add(t1);
            final ItemEntry current_item = all_entries.get(i);
            TextSupplementalAction t2 = new TextSupplementalAction(MainActivity.this, R.id.text2);
            t2.setOnActionClickListener(new BaseSupplementalAction.OnActionClickListener() {
                @Override
                public void onClick(Card card, View view) {
                    intent = new Intent();
                    Log.d("main", current_item.getId() + "");
                    intent.putExtra("item_id",current_item.getId());
                    intent.setClass(MainActivity.this, ShowitemActivity.class);
                    startActivity(intent);
                }
            });
            actions.add(t2);


            String textOverImage ="     "+current_item.getName()+"               "+'$'+current_item.getPrice();
            String datetime = DateFormat.format("kk:mm:ss",current_item.getDatetime()).toString();
            //ItemEntry current_item = all_entries.get(i);
            //String textOverImage ="     "+current_item.getName()+"               "+current_item.getPrice();
//            String description = current_item.getDescription();

            //Create a Card, set the title over the image and set the thumbnail
            MaterialLargeImageCard card =
                    MaterialLargeImageCard.with(MainActivity.this)
                            .setTextOverImage(textOverImage)
                            .setTitle(datetime)
                            .setSubTitle(current_item.getDescription())
                            .useDrawableUrl(piclist[i])
                            .setupSupplementalActions(R.layout.carddemo_native_material_supplemental_actions_large, actions)
                            .build();
            intent = new Intent();
            card.setOnClickListener(new Card.OnCardClickListener() {
                @Override
                public void onClick(Card card, View view) {
                    intent = new Intent();
                    Log.d("main", current_item.getId() + "");
                    intent.putExtra("item_id",current_item.getId());
                    intent.setClass(MainActivity.this, ShowitemActivity.class);
                    startActivity(intent);
                    Toast.makeText(MainActivity.this," Click on ActionArea ", Toast.LENGTH_SHORT).show();
                }
            });

            cards.add(card);
        }

        return cards;
    }



    /**
     * Update the adapter
     */
    private void updateAdapter(ArrayList<Card> cards) {
        if (cards != null) {
            mCardArrayAdapter.clear();
            mCardArrayAdapter.addAll(cards);
        }
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);

        //Searchable configuration
//        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
//        SearchView searchView = (SearchView) menu.findItem(R.id.menu_search).getActionView();    //MenuItemCompat.
//        searchView.setSearchableInfo( searchManager.getSearchableInfo(getComponentName()));

//        SearchView mSearchView = (SearchView) menu.findItem(R.id.menu_search);
//        setupSearchView(mSearchView);

        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
         if(id == R.id.menu_user) {
            Toast.makeText(MainActivity.this," Click on user ", Toast.LENGTH_SHORT).show();
            Intent profile = new Intent(MainActivity.this, ProfileActivity.class);
            startActivity(profile);
            return true;
        }
        else if(id == R.id.menu_chat) {
            Toast.makeText(MainActivity.this," Click on chat ", Toast.LENGTH_SHORT).show();

            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    //-------------------------------------------------------------------------------------------------------------
    // Images loader
    //-------------------------------------------------------------------------------------------------------------
    /**
     * Async Task to elaborate images
     */
    class LoaderAsyncTask extends AsyncTask<Void, Void, ArrayList<Card>> {

        LoaderAsyncTask() {
        }

        @Override
        protected ArrayList<Card> doInBackground(Void... params) {
            //elaborate images

            all_entries = item_db.getAllItemEntriesByCategory(category);
            total_num = all_entries.size();
            ArrayList<Card> cards = initCard();
            System.out.println("start post Excute "+cards.size()+" "+total_num);
            return cards;
        }

        @Override
        protected void onPostExecute(ArrayList<Card> cards) {
            //Update the adapter
            System.out.println("start post Excute");
            updateAdapter(cards);
            //displayList();
            mCardArrayAdapter.notifyDataSetChanged();
        }
    }
}
