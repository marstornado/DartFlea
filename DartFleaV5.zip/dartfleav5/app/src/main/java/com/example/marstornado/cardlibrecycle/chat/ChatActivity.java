package com.example.marstornado.cardlibrecycle.chat;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.marstornado.cardlibrecycle.ItemEntry;
import com.example.marstornado.cardlibrecycle.MainActivity;
import com.example.marstornado.cardlibrecycle.MapsActivity;
import com.example.marstornado.cardlibrecycle.ProfileActivity;
import com.example.marstornado.cardlibrecycle.R;
import com.example.marstornado.cardlibrecycle.ServerUtilities;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ChatActivity extends Activity {
    private final static String TAG = "ChatActivity: ";
//    public static final String PROPERTY_REG_ID = "Registration_id";
//    private static final String PROPERTY_APP_VERSION = "appVersion";
//    private final static int PLAY_SERVICES_RESOLUTION_REQUEST = 9000;

    public static final String FROM_USER_ID = "from_user_id";
    public static final String CONTACT_USER_ID = "contact_user_id";
    public static final String TO_USER_ID = CONTACT_USER_ID;
    public static final String DATE_TIME = "date_time";
    public static final String CONTENT = "content";

    //	private Button sendButton = null;
    private EditText contentEditText = null;
    private ImageView sendImage = null;
    private ImageView globeImage = null;

    public static ListView chatListView = null;
    public static List<Chat> chatList = null;
    public static ChatAdapter chatAdapter = null;

    private long myUserId;
    private long contactUserId = -1;


    public static boolean active = false;
    public static Activity chatActivity;



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.chat);

        myUserId = ProfileActivity.myUserId;
        Log.d(TAG, "myUserId = " + myUserId);
        contactUserId = getIntent().getLongExtra(CONTACT_USER_ID, -1);
        Log.d(TAG, "contactUserId = " + contactUserId);

        chatActivity = ChatActivity.this;

//        if(chatActivity == null) {
//            chatActivity = ChatActivity.this;
//            LayoutInflater inflater = ChatHeadService.inflater;
//            RelativeLayout chatheadView = (RelativeLayout) inflater.inflate(R.layout.chathead, null);
//            ImageView chatheadImg = (ImageView) chatheadView.findViewById(R.id.chathead_img);
//            ChatHeadService.chatHead2UserIdMap.put(chatheadView, contactUserId);
//            WindowManager.LayoutParams params = new WindowManager.LayoutParams(
//                    WindowManager.LayoutParams.WRAP_CONTENT,
//                    WindowManager.LayoutParams.WRAP_CONTENT,
//                    WindowManager.LayoutParams.TYPE_PHONE,
//                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
//                    PixelFormat.TRANSLUCENT);
//            params.gravity = Gravity.TOP | Gravity.LEFT;
//            params.x = 0;
//            params.y = 100;
//            ChatHeadService.windowManager.addView(chatheadView, params);
//            chatheadView.setOnTouchListener(ChatHeadService.chatHeadOnClickListener);
//        }

        contentEditText = (EditText) this.findViewById(R.id.et_content);

//        sendButton = (Button) this.findViewById(R.id.btn_send);
        sendImage = (ImageView) this.findViewById(R.id.send_image);
        globeImage = (ImageView) this.findViewById(R.id.globe_image);
        chatListView = (ListView) this.findViewById(R.id.listview);

        ChatDBHelper chatDB = new ChatDBHelper(this);
        //chatDB.deleteAllChats();

//        Chat chat1 = new Chat(myUserId, contactUserId, "test from user1");
//        long id1 = chatDB.addChat(chat1);
//        chat1.setId(id1);
//        Log.d(TAG, "id1 = " + id1);
//
//        try{
//            Thread.sleep(500);
//        } catch (InterruptedException e){
//            e.printStackTrace();
//        }
//        Chat chat2 = new Chat(contactUserId, myUserId, "test from user2");
//        long id2 = chatDB.addChat(chat2);
//        chat2.setId(id2);
//        Log.d(TAG, "id2 = " + id2);


        chatList = chatDB.getAllChats(myUserId, contactUserId);
        Log.d(TAG, "before_new_ChatAdapter: myUserId = " + myUserId + ", getMyUserId = " + getMyUserId());
        chatAdapter = new ChatAdapter(this,chatList);
        chatListView.setAdapter(chatAdapter);

        sendImage.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!contentEditText.getText().toString().equals("")) {
                    //发送消息
                    send();
                }else {
                    Toast.makeText(ChatActivity.this, "Content is empty", Toast.LENGTH_SHORT).show();
                }
            }
        });
        globeImage.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ChatActivity.this, MapsActivity.class);
                startActivity(intent);
            }
        });

    }



    @Override
    protected void onResume() {
        // TODO Auto-generated method stub
        super.onResume();
        active = true;
    }

    @Override
    protected void onPause() {
        // TODO Auto-generated method stub
        super.onPause();
        active = false;
    }

    @Override
    protected void onDestroy() {
        // TODO Auto-generated method stub
        super.onDestroy();
        active = false;
    }




    private void send(){

        //signUp();

        Chat chat = new Chat(myUserId, contactUserId, contentEditText.getText().toString());

        Log.d(TAG, "send: time = " + chat.getmTimeInMillis());
        ChatDBHelper chatDB = new ChatDBHelper(this);
        long id = chatDB.addChat(chat);
        chat.setId(id);
        Log.d(TAG, "id = " + id);

        chatList.add(chat);
        chatAdapter.notifyDataSetChanged();
        chatListView.setSelection(chatList.size() - 1);
        contentEditText.setText("");

        JSONObject json = new JSONObject();
        try{
            //json.put(PROPERTY_REG_ID, regid);
            json.put(FROM_USER_ID, myUserId);
            json.put(CONTACT_USER_ID, contactUserId);
            json.put(DATE_TIME, chat.getmTimeInMillis());
            json.put(CONTENT, chat.getmContent());
            //Log.d(TAG, "send: json.time = " + json.getInt(DATE_TIME));
        }catch(Exception e){
            e.printStackTrace();
        }

        String out = json.toString();
        Log.d(TAG, "send(): " + out);
        sendChatToServer(out);

//        testSendItemToServer();

    }



    private void testSendItemToServer(){
        Long time = Calendar.getInstance().getTimeInMillis();
        ItemEntry item = new ItemEntry(1L, ProfileActivity.myUserId, "item1", 12.5, "description",
                1, 2, 1234567L, time, new ArrayList<String>(), "compare_image", 13.5);

        JSONObject json = item.getJSONObject();
        String out = json.toString();
        Log.d(TAG, "send(): " + out);
        sendItemToServer(out);
    }

    private void sendItemToServer(String data) {
        new AsyncTask<String, Void, String>() {
            @Override
            protected String doInBackground(String... arg0) {
                String url = getString(R.string.server_addr) + "/postItem.do";
                //String url = getString(R.string.server_addr) + "/post.do";
                String res = "";
                Map<String, String> params = new HashMap<String, String>();
                params.put("data", arg0[0]);
                Log.d("data", arg0[0]);
                //params.put("from", "phone");
                try {
                    //res = ServerUtilities.post(url, params, "application/json");
                    res = ServerUtilities.post(url, params);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
                return res;
            }

            @Override
            protected void onPostExecute(String res) {
                Log.d(TAG, "sendChatToServer: res = " + res);
                //mPostText.setText("");
                //refreshPostHistory();
            }
        }.execute(data);
    }




    private void sendChatToServer(String data) {
        new AsyncTask<String, Void, String>() {
            @Override
            protected String doInBackground(String... arg0) {
                String url = getString(R.string.server_addr) + "/sendChatToServer.do";
                //String url = getString(R.string.server_addr) + "/post.do";
                String res = "";
                Map<String, String> params = new HashMap<String, String>();
                params.put("data", arg0[0]);
                Log.d("data", arg0[0]);
                //params.put("from", "phone");
                try {
                    //res = ServerUtilities.post(url, params, "application/json");
                    res = ServerUtilities.post(url, params);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
                return res;
            }

            @Override
            protected void onPostExecute(String res) {
                Log.d(TAG, "sendChatToServer: res = " + res);
                //mPostText.setText("");
                //refreshPostHistory();
            }
        }.execute(data);
    }



    public long getMyUserId(){
        return myUserId;
    }
}