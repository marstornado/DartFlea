package edu.dartmouth.cs.gcmdemo.server.data;

import java.util.Date;

public class PostEntity {
	//public static String ENTITY_KIND_PARENT = "PostParent";
	//public static String ENTITY_PARENT_KEY = ENTITY_KIND_PARENT;
	public static String ENTITY_KIND_POST = "Post";

	//public static String FIELD_NAME_DATE = "Date";
	//public static String FIELD_NAME_POST = "Post";

	public static final String PROPERTY_REG_ID = "Registration_id";
	public static String FIELD_NAME_ID = "id";
	public static String FIELD_NAME_INPUT_TYPE = "inputType";
	public static String FIELD_NAME_ACTIVITY_TYPE = "activityType";
	public static String FIELD_NAME_DATETIME = "dateTime";
	public static String FIELD_NAME_DURATION = "duration";
	public static String FIELD_NAME_DISTANCE = "distance";
	public static String FIELD_NAME_CALORIES = "calories";
	public static String FIELD_NAME_HEARTRATE = "heartrate";
	public static String FIELD_NAME_COMMENT = "comment";
	public static String FIELD_NAME_CLIMB = "climb";
	public static String FIELD_NAME_AVG_SPEED = "avgspeed";
	public static String FIELD_NAME_UNIT = "unit"; 

	public Date mPostDate;
	public String mPostString;
	
	public Long id;
	public String regid;
	public String mInputType;        // Manual, GPS or automatic
	public String mActivityType;     // Running, cycling etc.
	public String mDateTime;    // When does this entry happen
	public double mDuration;         // Exercise duration in seconds
	public double mDistance;      // Distance traveled. Either in meters or feet.
	public double mCurSpeed;       // Average pace
	public double mAvgSpeed;      // Average speed
	public int mCalorie;          // Calories burnt
	public double mClimb;         // Climb. Either in meters or feet.
	public int mHeartRate;        // Heart rate
	public String mComment;       // Comments
	public String unit;
	
	public PostEntity() {
	}

	public PostEntity(String post, Date date) {
		mPostDate = date;
		mPostString = post;
	}
	
	public PostEntity(String inputType, Date date, Long _id) {
		mPostDate = date;
		mInputType = inputType;
		id = _id;
	}
	
	public PostEntity(String regid,Long id,String inputType,String activityType,String dateTime,double duration,double distance,int calories,
			int heartrate, String comment,double climb, double avgspeed, String unit) {
		this.regid = regid;
		this.id = id;
		this.mInputType = inputType;
		this.mActivityType = activityType;
		this.mDateTime = dateTime;
		this.mDuration = duration;
		this.mDistance = distance;
		this.mCalorie = calories;
		this.mHeartRate = heartrate;
		this.mComment = comment;
		this.mClimb = climb;
		this.mAvgSpeed = avgspeed;
		this.unit = unit;
		
	}
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getmInputType() {
        return mInputType;
    }

    public void setmInputType(String mInputType) {
        this.mInputType = mInputType;
    }

    public String getmActivityType() {
        return mActivityType;
    }

    public void setmActivityType(String mActivityType) {
        this.mActivityType = mActivityType;
    }

    public String getmDateTime() {
        return mDateTime;
    }

    public void setmDateTime(String mDateTime) {
        this.mDateTime = mDateTime;
    }

    public double getmDuration() {
        return mDuration;
    }

    public void setmDuration(double mDuration) {
        this.mDuration = mDuration;
    }

    public double getmDistance() {
        return mDistance;
    }

    public void setmDistance(double mDistance) {
        this.mDistance = mDistance;
    }

    public double getmCurSpeed() {
        return mCurSpeed;
    }

    public void setmCurSpeed(double mCurSpeed) {
        this.mCurSpeed = mCurSpeed;
    }

    public double getmAvgSpeed() {
        return mAvgSpeed;
    }

    public void setmAvgSpeed(double mAvgSpeed) {
        this.mAvgSpeed = mAvgSpeed;
    }

    public int getmCalorie() {
        return mCalorie;
    }

    public void setmCalorie(int mCalorie) {
        this.mCalorie = mCalorie;
    }

    public double getmClimb() {
        return mClimb;
    }

    public void setmClimb(double mClimb) {
        this.mClimb = mClimb;
    }

    public int getmHeartRate() {
        return mHeartRate;
    }

    public void setmHeartRate(int mHeartRate) {
        this.mHeartRate = mHeartRate;
    }

    public String getmComment() {
        return mComment;
    }

    public void setmComment(String mComment) {
        this.mComment = mComment;
    }
    
}
