package edu.dartmouth.cs.gcmdemo.server.data;

import java.util.ArrayList;
import java.util.List;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.PreparedQuery;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.Query.Filter;
import com.google.appengine.api.datastore.Query.FilterOperator;
import com.google.appengine.api.datastore.Query.FilterPredicate;
import com.google.appengine.api.datastore.Query.CompositeFilterOperator;
import com.google.appengine.api.datastore.Query.SortDirection;
import com.google.appengine.api.memcache.MemcacheServicePb.MemcacheDeleteRequest.Item;
import com.google.appengine.labs.repackaged.org.json.JSONArray;
import com.google.appengine.labs.repackaged.org.json.JSONException;
import com.google.appengine.labs.repackaged.org.json.JSONObject;

public class ItemDatastore {
	private static final DatastoreService mDatastore = DatastoreServiceFactory
			.getDatastoreService();
	public static final String ENTITY_ITEM_PARENT = "item_parent";
	public static final String ENTITY_KIND_ITEM = "item";
	
	public static String FIELD_NAME_ID = "id";
	public static String FIELD_NAME_ITEM_ID = "itemId";
	public static String FIELD_NAME_USER_ID = "userid";
	public static String FIELD_NAME_ITEMNAME = "itemname";
	public static String FIELD_NAME_PRICE = "price";
	public static String FIELD_NAME_DESCRIPTION = "description";
	public static String FIELD_NAME_STATUS = "status";
	public static String FIELD_NAME_CATEGORY = "category";
	public static String FIELD_NAME_BARCODE = "barcode";
	public static String FIELD_NAME_DATETIME = "datetime";
	public static String FIELD_NAME_IMAGES = "images";
	public static String FIELD_NAME_COMPARE_IMAGE = "compare_images";
	public static String FIELD_NAME_COMPARE_PRICE = "compare_price";
	
	private static Key getParentKey() {
		return KeyFactory.createKey(ENTITY_ITEM_PARENT, ENTITY_ITEM_PARENT);
	}

	private static void createParentEntity() {
		Entity entity = new Entity(getParentKey());
		mDatastore.put(entity);
	}
	
	public static Key getItemKey(long itemId) {
		//List<String> devices;

		Query query = new Query(ENTITY_KIND_ITEM);
		Iterable<Entity> entities = mDatastore.prepare(query).asIterable();
		
		for (Entity entity : entities) {
			long id = (Long) entity.getProperty(FIELD_NAME_ID);
			if(id == itemId){
				return entity.getKey();
			}
		}

		return null;
	}
	
	public static void add(ItemEntity item) {		
		Entity entity = new Entity(ENTITY_KIND_ITEM, item.getId());
		entity.setProperty(FIELD_NAME_ID, item.getId());
		entity.setProperty(FIELD_NAME_ITEM_ID, item.getmItemId());
		entity.setProperty(FIELD_NAME_USER_ID, item.getmUserId());
		entity.setProperty(FIELD_NAME_ITEMNAME, item.getmItemname());
		entity.setProperty(FIELD_NAME_PRICE, item.getmPrice());
		entity.setProperty(FIELD_NAME_DESCRIPTION, item.getmDescription());
		entity.setProperty(FIELD_NAME_STATUS, item.getmStatus());
		entity.setProperty(FIELD_NAME_CATEGORY, item.getmCategory());
		entity.setProperty(FIELD_NAME_BARCODE, item.getmBarcode());
		entity.setProperty(FIELD_NAME_DATETIME, item.getmDatetime());
		entity.setProperty(FIELD_NAME_IMAGES, item.getmImages());
//		try{
//			JSONArray array = new JSONArray();
//			for(String url : item.getmImages()){
//				JSONObject jo = new JSONObject();
//				jo.put("url", url);
//				array.put(jo);
//			}
//			JSONObject json = new JSONObject();
//			json.put("images", array);
//			entity.setProperty(FIELD_NAME_IMAGES, json.toString());
//		} catch(JSONException e){
//			e.printStackTrace();
//		}
		entity.setProperty(FIELD_NAME_COMPARE_IMAGE, item.getmCompareImage());
		entity.setProperty(FIELD_NAME_COMPARE_PRICE, item.getmComparePrice());
		mDatastore.put(entity);
	}

	public static ArrayList<ItemEntity> getAllItems() {
		ArrayList<ItemEntity> resultList = new ArrayList<ItemEntity>();;

		Query query = new Query(ENTITY_KIND_ITEM);
		query.setFilter(null);
		//query.setAncestor(getParentKey());
		query.addSort(FIELD_NAME_DATETIME, SortDirection.DESCENDING);
		PreparedQuery pq = mDatastore.prepare(query);

		for (Entity entity : pq.asIterable()) {
			ItemEntity item = new ItemEntity(entity);
			resultList.add(item);
		}
		return resultList;
	}
	  
	public static boolean deleteByItemIdAndUserId(long itemId, long userId) {
		Filter filterItemId = new FilterPredicate(FIELD_NAME_ITEM_ID,
				FilterOperator.EQUAL, itemId);
		Filter filterUserId = new FilterPredicate(FIELD_NAME_USER_ID,
				FilterOperator.EQUAL, userId);
		Filter filter =
				  CompositeFilterOperator.and(filterItemId, filterUserId);
		Query query = new Query(ENTITY_KIND_ITEM);
		query.setFilter(filter);

		// Use PreparedQuery interface to retrieve results
		PreparedQuery pq = mDatastore.prepare(query);

		Entity result = pq.asSingleEntity();
		boolean ret = false;
		if (result != null) {
			// delete
			mDatastore.delete(result.getKey());
			ret = true;
		}
		return ret;
	}
	
	public static void deleteAllItems() {
		Query query = new Query(ENTITY_KIND_ITEM);
		// get every record from datastore, no filter
		query.setFilter(null);
		// set query's ancestor to get strong consistency
		query.setAncestor(getParentKey());

		PreparedQuery pq = mDatastore.prepare(query);

		for (Entity entity : pq.asIterable()) {
			mDatastore.delete(entity.getKey());
		}
	}
}
