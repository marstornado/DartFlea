package edu.dartmouth.cs.gcmdemo.gcm;

public class Response {
	int mHttpStatus = -1;
	String mMessage = "";
}
