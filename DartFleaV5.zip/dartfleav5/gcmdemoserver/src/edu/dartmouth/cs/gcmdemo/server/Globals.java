package edu.dartmouth.cs.gcmdemo.server;

public class Globals {
	// API key is defined in here
	public static final String GCMAPIKEY = "AIzaSyBiJ9i3nM06B4fWi7RVzDlCAuhbsHTgtr8";
}
