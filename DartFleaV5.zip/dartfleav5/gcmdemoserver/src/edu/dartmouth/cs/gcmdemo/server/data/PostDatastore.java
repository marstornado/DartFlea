package edu.dartmouth.cs.gcmdemo.server.data;

import java.util.ArrayList;
import java.util.Date;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.PreparedQuery;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.Query.Filter;
import com.google.appengine.api.datastore.Query.FilterOperator;
import com.google.appengine.api.datastore.Query.SortDirection;

public class PostDatastore {
	private static final DatastoreService mDatastore = DatastoreServiceFactory
			.getDatastoreService();
/*
	private static Key getParentKey() {
		return KeyFactory.createKey(PostEntity.ENTITY_KIND_PARENT,
				PostEntity.ENTITY_PARENT_KEY);
	}
*/
	private static Key getParentKey(String regid) {
		return RegDatastore.getDeviceKey(regid);
	}
/*
	private static void createParentEntity() {
		Entity entity = new Entity(getParentKey());

		mDatastore.put(entity);
	}
*/
	public static boolean add(PostEntity post) {
		Key parentKey = getParentKey(post.regid);
		/*
		try {
			mDatastore.get(parentKey);
		} catch (Exception ex) {
			createParentEntity();
		}
*/
		Entity entity = new Entity(PostEntity.ENTITY_KIND_POST,
				post.id, parentKey);

		entity.setProperty(PostEntity.PROPERTY_REG_ID, post.regid);
        entity.setProperty(PostEntity.FIELD_NAME_ID, post.id);
        entity.setProperty(PostEntity.FIELD_NAME_INPUT_TYPE, post.mInputType);
        entity.setProperty(PostEntity.FIELD_NAME_ACTIVITY_TYPE, post.mActivityType);
        entity.setProperty(PostEntity.FIELD_NAME_DATETIME, post.mDateTime);
        entity.setProperty(PostEntity.FIELD_NAME_DURATION, post.mDuration);
        entity.setProperty(PostEntity.FIELD_NAME_DISTANCE, post.mDistance);
        entity.setProperty(PostEntity.FIELD_NAME_CALORIES, post.mCalorie);
        entity.setProperty(PostEntity.FIELD_NAME_HEARTRATE, post.mHeartRate);
        entity.setProperty(PostEntity.FIELD_NAME_COMMENT, post.mComment);
        entity.setProperty(PostEntity.FIELD_NAME_CLIMB, post.mClimb);
        entity.setProperty(PostEntity.FIELD_NAME_AVG_SPEED, post.mAvgSpeed);
        entity.setProperty(PostEntity.FIELD_NAME_UNIT, post.unit);

		mDatastore.put(entity);

		return true;
	}

	public static ArrayList<PostEntity> query(String regid) {
		ArrayList<PostEntity> resultList = new ArrayList<PostEntity>();

		Query query = new Query(PostEntity.ENTITY_KIND_POST);
		query.setFilter(null);
		query.setAncestor(getParentKey(regid));
		query.addSort(PostEntity.FIELD_NAME_ID, SortDirection.ASCENDING);
		PreparedQuery pq = mDatastore.prepare(query);

		for (Entity entity : pq.asIterable()) {
			PostEntity post = new PostEntity();
			//post.mPostDate = (Date)entity.getProperty(PostEntity.FIELD_NAME_DATE);
			//post.mPostString = (String)entity.getProperty(PostEntity.FIELD_NAME_POST);
			post.regid = (String)entity.getProperty(PostEntity.PROPERTY_REG_ID);
            post.id = (long)entity.getProperty(PostEntity.FIELD_NAME_ID);
            post.mInputType = (String)entity.getProperty(PostEntity.FIELD_NAME_INPUT_TYPE);
            post.mActivityType = (String)entity.getProperty(PostEntity.FIELD_NAME_ACTIVITY_TYPE);
            post.mDateTime = (String)entity.getProperty(PostEntity.FIELD_NAME_DATETIME);
            post.mDuration = (double)entity.getProperty(PostEntity.FIELD_NAME_DURATION);
            post.mDistance = (double)entity.getProperty(PostEntity.FIELD_NAME_DISTANCE);
            post.mCalorie = ((Long)entity.getProperty(PostEntity.FIELD_NAME_CALORIES)).intValue();
            post.mHeartRate = ((Long)entity.getProperty(PostEntity.FIELD_NAME_HEARTRATE)).intValue();
            post.mComment = (String)entity.getProperty(PostEntity.FIELD_NAME_COMMENT);
            post.mClimb = (double)entity.getProperty(PostEntity.FIELD_NAME_CLIMB);
            post.mAvgSpeed = (double)entity.getProperty(PostEntity.FIELD_NAME_AVG_SPEED);
            post.unit = (String)entity.getProperty(PostEntity.FIELD_NAME_UNIT);
            
			resultList.add(post);
		}
		return resultList;
	}
	  public static boolean delete(long id,String regid) {
	        // you can also use name to get key, then use the key to delete the
	        // entity from datastore directly
	        // because name is also the entity's key

	        // query
	        Filter filter = new Query.FilterPredicate(PostEntity.FIELD_NAME_ID,
	                FilterOperator.EQUAL, id);

	        Query query = new Query(PostEntity.ENTITY_KIND_POST,getParentKey(regid));
	        query.setFilter(filter);

	        // Use PreparedQuery interface to retrieve results
	        PreparedQuery pq = mDatastore.prepare(query);

	        Entity result = pq.asSingleEntity();
	        boolean ret = false;
	        if (result != null) {
	            // delete
	            mDatastore.delete(result.getKey());
	            ret = true;
	        }

	        return ret;
	    }
	    public static void deleteAll(String regid){
	        

	        Query query = new Query(PostEntity.ENTITY_KIND_POST);
	        query.setFilter(null);
	        query.setAncestor(getParentKey(regid));
	        query.addSort(PostEntity.FIELD_NAME_ID, SortDirection.ASCENDING);
	        PreparedQuery pq = mDatastore.prepare(query);

	        for (Entity entity : pq.asIterable()) {
	            mDatastore.delete(entity.getKey());   
	        } 
	    }
}
