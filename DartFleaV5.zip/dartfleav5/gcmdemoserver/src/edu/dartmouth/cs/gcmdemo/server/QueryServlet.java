package edu.dartmouth.cs.gcmdemo.server;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.dartmouth.cs.gcmdemo.server.data.PostDatastore;
import edu.dartmouth.cs.gcmdemo.server.data.PostEntity;
import edu.dartmouth.cs.gcmdemo.server.data.RegDatastore;

public class QueryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {
        Map<String,ArrayList<PostEntity>> posts = new HashMap<String, ArrayList<PostEntity>> ();
        List<String> devices = RegDatastore.getDevices();
        System.out.println("device " + devices);
        
        for(String device:devices){
            ArrayList<PostEntity> postList = PostDatastore.query(device);

            for(int i=0; i<postList.size(); i++) {
            	System.out.println(postList.get(i).getmActivityType());
            }
            
            posts.put(device, postList);
        }
        
		//ArrayList<PostEntity> postList = PostDatastore.query();
        
		
		req.setAttribute("postList", posts);
		
		getServletContext().getRequestDispatcher("/main.jsp").forward(req, resp);
	}
	
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {
		doPost(req, resp);
	}
	
}
