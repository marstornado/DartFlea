package edu.dartmouth.cs.gcmdemo.server;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.appengine.labs.repackaged.org.json.JSONArray;
import com.google.appengine.labs.repackaged.org.json.JSONException;
import com.google.appengine.labs.repackaged.org.json.JSONObject;

import edu.dartmouth.cs.gcmdemo.server.data.PostDatastore;
import edu.dartmouth.cs.gcmdemo.server.data.PostEntity;

public class PostServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {
		String postText = req.getParameter("post_text");
		System.out.println("post " + postText);
		
		String mInputType="";
		Long id = 0L;
		System.out.println("test " + postText);
		try {
			JSONObject jsonObject = new JSONObject(postText);
			JSONArray jsonArray = jsonObject.getJSONArray("array");
			for(int j=0; j<jsonArray.length();j++)
		    {
				JSONObject curr = jsonArray.getJSONObject(j);

		        mInputType = curr.getString("inputType");
		        id = curr.getLong("id");
		        System.out.println("id " + id);
		        System.out.println("mInputType " + mInputType);
		        //Do something with Prize
		    }
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//postText ="test2";
		Date now = new Date();

		PostDatastore.add(new PostEntity(postText, now));

		// notify
		String from = req.getParameter("from");
		if (from == null || !from.equals("phone")) {
			resp.sendRedirect("/sendmsg.do");
		}
	}

	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {
		doPost(req, resp);
	}
}
