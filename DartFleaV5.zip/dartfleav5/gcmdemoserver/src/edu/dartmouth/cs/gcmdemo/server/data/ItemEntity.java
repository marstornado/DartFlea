package edu.dartmouth.cs.gcmdemo.server.data;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.google.appengine.api.datastore.Entity;
import com.google.appengine.labs.repackaged.org.json.JSONArray;
import com.google.appengine.labs.repackaged.org.json.JSONException;
import com.google.appengine.labs.repackaged.org.json.JSONObject;

import edu.dartmouth.cs.gcmdemo.server.PostServlet;

public class ItemEntity {
	private static final Logger mLogger = Logger
			.getLogger(ItemEntity.class.getName());
//public static String ENTITY_KIND_PARENT = "PostParent";
	//public static String ENTITY_PARENT_KEY = ENTITY_KIND_PARENT;
	public static String ENTITY_KIND_ITEM = "Item";

	//public static String FIELD_NAME_DATE = "Date";
	//public static String FIELD_NAME_POST = "Post";

//	public static final String PROPERTY_REG_ID = "Registration_id";
	public static String FIELD_NAME_ID = "id";
	public static String FIELD_NAME_ITEM_ID = "itemId";
	public static String FIELD_NAME_USER_ID = "userid";
	public static String FIELD_NAME_ITEMNAME = "itemname";
	public static String FIELD_NAME_PRICE = "price";
	public static String FIELD_NAME_DESCRIPTION = "description";
	public static String FIELD_NAME_STATUS = "status";
	public static String FIELD_NAME_CATEGORY = "category";
	public static String FIELD_NAME_BARCODE = "barcode";
	public static String FIELD_NAME_DATETIME = "datetime";
	public static String FIELD_NAME_IMAGES = "images";
	public static String FIELD_NAME_COMPARE_IMAGE = "compare_images";
	public static String FIELD_NAME_COMPARE_PRICE = "compare_price";
	
	private Long id;
	private Long mItemId;
	private Long mUserId;
	private String mItemname;
	private double mPrice;
	private String mDescription;
	private int mStatus;
	private int mCategory;
	private Long mBarcode;
	private Long mDatetime;
	//private ArrayList<String> mImages;
	private String mImages; //the json containning json array of image urls
	private String mCompareImage;
	private double mComparePrice;
	

	public ItemEntity() {
        
    }

    public ItemEntity(Long mItemId, Long mUserId, String mItemname, double mPrice, String mDescription, 
                      int mStatus, int mCategory, Long mBarcode, Long mDatetime, 
                      String mImages, String mCompareImage, double mComparePrice) {
    	this.mItemId = mItemId;
    	this.mUserId = mUserId;
        this.mItemname = mItemname;
        this.mPrice = mPrice;
        this.mDescription = mDescription;
        this.mStatus = mStatus;
        this.mCategory = mCategory;
        this.mBarcode = mBarcode;
        this.mDatetime = mDatetime;
        this.mImages = mImages;
        this.mCompareImage = mCompareImage;
        this.mComparePrice = mComparePrice;
    }
    
    public ItemEntity(JSONObject json){
    	if(json == null){
        	mLogger.log(Level.SEVERE, "UserEntity: json object is null");
        }
        try {
        	this.mItemId = json.getLong(FIELD_NAME_ITEM_ID);
        	this.mUserId = json.getLong(FIELD_NAME_USER_ID);
            this.mItemname = json.getString(FIELD_NAME_ITEMNAME);
            this.mPrice = json.getDouble(FIELD_NAME_PRICE);
            this.mDescription = json.getString(FIELD_NAME_DESCRIPTION);
            this.mStatus = json.getInt(FIELD_NAME_STATUS);
            this.mCategory = json.getInt(FIELD_NAME_CATEGORY);
            this.mBarcode = json.getLong(FIELD_NAME_BARCODE);
            this.mDatetime = json.getLong(FIELD_NAME_DATETIME);
            this.mImages = json.getString(FIELD_NAME_IMAGES);
//            this.mImages = new ArrayList<String>();
//            String json_string = json.getString(FIELD_NAME_IMAGES);
//            JSONObject jo = new JSONObject(json_string);
//            JSONArray array = jo.getJSONArray("images");
//            int size = array.length();
//            for(int i=0;i<size;i++){
//     		   JSONObject obj = array.getJSONObject(i);
//     		   this.mImages.add(obj.getString("url"));
//            }
            this.mCompareImage = json.getString(FIELD_NAME_COMPARE_IMAGE);
            this.mComparePrice = json.getDouble(FIELD_NAME_COMPARE_PRICE);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
	
    public ItemEntity(Entity entity){
    	this.id = (long)entity.getProperty(FIELD_NAME_ID);
    	this.mItemId = (long)entity.getProperty(FIELD_NAME_ITEM_ID);
    	this.mUserId = (long)entity.getProperty(FIELD_NAME_USER_ID);
        this.mItemname = (String)entity.getProperty(FIELD_NAME_ITEMNAME);
        this.mPrice = (Double)entity.getProperty(FIELD_NAME_PRICE);
        this.mDescription = (String)entity.getProperty(FIELD_NAME_DESCRIPTION);
        this.mStatus = (int)((long)entity.getProperty(FIELD_NAME_STATUS));
        this.mCategory = (int)(long)entity.getProperty(FIELD_NAME_CATEGORY);
        this.mBarcode = (long)entity.getProperty(FIELD_NAME_BARCODE);
        this.mDatetime = (long)entity.getProperty(FIELD_NAME_DATETIME);
        this.mImages = (String)entity.getProperty(FIELD_NAME_IMAGES);
//        this.mImages = new ArrayList<String>();
//        try{
//        	JSONObject json = new JSONObject((String)entity.getProperty(FIELD_NAME_IMAGES));
//            JSONArray array = json.getJSONArray("images");
//            int size = array.length();
//            for(int i=0;i<size;i++){
//     		   JSONObject obj = array.getJSONObject(i);
//     		   this.mImages.add(obj.getString("url"));
//            }
//        } catch (JSONException e){
//        	e.printStackTrace();
//        }
        this.mCompareImage = (String)entity.getProperty(FIELD_NAME_COMPARE_IMAGE);
        this.mComparePrice = (Double)entity.getProperty(FIELD_NAME_COMPARE_PRICE);
    }
	
    public JSONObject getJSONObject(){
    	JSONObject json = new JSONObject();
        try{
        	json.put(FIELD_NAME_ID, id);
            json.put(FIELD_NAME_ITEM_ID, mItemId);
            json.put(FIELD_NAME_USER_ID, mUserId);
            json.put(FIELD_NAME_ITEMNAME, mItemname);
            
            json.put(FIELD_NAME_PRICE, mPrice);
            json.put(FIELD_NAME_DESCRIPTION, mDescription);
            json.put(FIELD_NAME_STATUS, mStatus);
            
            json.put(FIELD_NAME_CATEGORY, mCategory);
            json.put(FIELD_NAME_BARCODE, mBarcode);
            json.put(FIELD_NAME_DATETIME, mDatetime);
           
            json.put(FIELD_NAME_IMAGES, mImages);
            json.put(FIELD_NAME_COMPARE_IMAGE, mCompareImage);
            json.put(FIELD_NAME_COMPARE_PRICE, mComparePrice);
        }catch(Exception e){
            e.printStackTrace();
        }
        return json;
    }
    
	public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    
    public Long getmItemId() {
        return mItemId;
    }

    public void setmItemId(Long mItemId) {
        this.mItemId = mItemId;
    }

    public Long getmUserId() {
        return mUserId;
    }

    public void setmUserId(Long mUserId) {
        this.mUserId = mUserId;
    }

    public String getmItemname() {
        return mItemname;
    }

    public void setmItemname(String mItemname) {
        this.mItemname = mItemname;
    }

    public double getmPrice() {
        return mPrice;
    }

    public void setmPrice(double mPrice) {
        this.mPrice = mPrice;
    }

    public String getmDescription() {
        return mDescription;
    }

    public void setmDescription(String mDescription) {
        this.mDescription = mDescription;
    }

    public int getmStatus() {
        return mStatus;
    }

    public void setmStatus(int mStatus) {
        this.mStatus = mStatus;
    }

    public int getmCategory() {
        return mCategory;
    }

    public void setmCategory(int mCategory) {
        this.mCategory = mCategory;
    }

    public Long getmBarcode() {
        return mBarcode;
    }

    public void setmBarcode(Long mBarcode) {
        this.mBarcode = mBarcode;
    }

    public Long getmDatetime() {
        return mDatetime;
    }

    public void setmDatetime(Long mDatetime) {
        this.mDatetime = mDatetime;
    }
    
    public String getmDatetimeString(){
    	mLogger.log(Level.INFO, "ItemEntity: mDatetime = " + mDatetime);
    	Calendar dateTime = Calendar.getInstance();
    	dateTime.setTimeInMillis(mDatetime);
    	SimpleDateFormat formatter = new SimpleDateFormat("hh:mm:ss MMM dd yyyy");
		String time = formatter.format(dateTime.getTime());
		return time;
    }

    public String getmImages() {
        return mImages;
    }

    public void setmImages(String mImages) {
        this.mImages = mImages;
    }

    public String getmCompareImage() {
        return mCompareImage;
    }

    public void setmCompareImage(String mCompareImage) {
        this.mCompareImage = mCompareImage;
    }

    public double getmComparePrice() {
        return mComparePrice;
    }

    public void setmComparePrice(double mComparePrice) {
        this.mComparePrice = mComparePrice;
    }
	
    public String toString(){
    	return "id = " + id + ", itemId = " + mItemId + ", userId = " 
				+ mUserId + ", name = " + mItemname + ", price = " 
    			+ mPrice + ", description = " + mDescription + ", status = " 
				+ mStatus + ", category = " + mCategory + ", barcode = " 
    			+ mBarcode + ", time = " + getmDatetimeString() + ", compare_image = "
    			+ mCompareImage + ", compare_price = " + mComparePrice; 
    }
}
