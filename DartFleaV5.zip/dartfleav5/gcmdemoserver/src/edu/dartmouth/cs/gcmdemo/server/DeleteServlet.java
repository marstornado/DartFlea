package edu.dartmouth.cs.gcmdemo.server;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.dartmouth.cs.gcmdemo.server.data.PostDatastore;



public class DeleteServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {
		long id = Integer.parseInt(req.getParameter("id"));
		String regid = req.getParameter("regid");
		PostDatastore.delete(id,regid);
		// notify
		System.out.println("send delete "+id + regid);
		resp.sendRedirect("/sendmsg.do?id="+id+"&regid="+regid);
		
		
	}

	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {
		doGet(req, resp);
	}
}
