package edu.dartmouth.cs.gcmdemo.server.data;

import java.util.ArrayList;
import java.util.List;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.datastore.PreparedQuery;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.Query.Filter;
import com.google.appengine.api.datastore.Query.FilterOperator;
import com.google.appengine.api.datastore.Query.FilterPredicate;
import com.google.appengine.api.datastore.Query.SortDirection;

public class UserDatastore {
	
	private static final DatastoreService mDatastore = DatastoreServiceFactory
			.getDatastoreService();
	public static final String ENTITY_USER_PARENT = "user_parent";
	public static final String ENTITY_KIND_USER = "user";
	
	public static String FIELD_NAME_ID = "id";
	public static String FIELD_NAME_REG_ID = "Registration_id";
	public static String FIELD_NAME_USERNAME = "username";
	public static String FIELD_NAME_EMAIL = "email";
	public static String FIELD_NAME_PASSWORD = "password";
	public static String FIELD_NAME_MOTIVATION = "motivation";
	public static String FIELD_NAME_PHONE = "phone";
	public static String FIELD_NAME_CONTACTS = "contacts";
	
	private static Key getParentKey() {
		return KeyFactory.createKey(ENTITY_USER_PARENT, ENTITY_USER_PARENT);
	}

	private static void createParentEntity() {
		Entity entity = new Entity(getParentKey());

		mDatastore.put(entity);
	}
	
	public static Key getUserKey(long userId) {
		//List<String> devices;

		Query query = new Query(ENTITY_KIND_USER);
		Iterable<Entity> entities = mDatastore.prepare(query).asIterable();
		
		for (Entity entity : entities) {
			long id = (Long) entity.getProperty(FIELD_NAME_ID);
			if(id == userId){
				return entity.getKey();
			}
		}

		return null;
	}
	
	public static void add(UserEntity user) {
		Entity entity = new Entity(ENTITY_KIND_USER, user.getId());
		entity.setProperty(FIELD_NAME_ID, user.getId());
		entity.setProperty(FIELD_NAME_REG_ID, user.getmRegid());
		entity.setProperty(FIELD_NAME_USERNAME, user.getmUsername());
		entity.setProperty(FIELD_NAME_EMAIL, user.getmEmail());
		entity.setProperty(FIELD_NAME_PASSWORD, user.getmPassword());
		entity.setProperty(FIELD_NAME_MOTIVATION, user.getmMotivation());
		entity.setProperty(FIELD_NAME_PHONE, user.getmPhone());
		mDatastore.put(entity);
	}
	
	public static String getRegIdByUserId(Long id) {
		Query query = new Query(ENTITY_KIND_USER);
		Filter filter = new Query.FilterPredicate(FIELD_NAME_ID,
		          FilterOperator.EQUAL, id);
		query.setFilter(filter);
		// Use PreparedQuery interface to retrieve results
		PreparedQuery pq = mDatastore.prepare(query);
		Entity result = pq.asSingleEntity();
		
		return (String)result.getProperty(FIELD_NAME_REG_ID);
	}
	
	public static boolean deleteByUserId(long id) {

		Filter filter = new FilterPredicate(FIELD_NAME_ID,
				FilterOperator.EQUAL, id);
		Query query = new Query(ENTITY_KIND_USER);
		query.setFilter(filter);

		// Use PreparedQuery interface to retrieve results
		PreparedQuery pq = mDatastore.prepare(query);

		Entity result = pq.asSingleEntity();
		boolean ret = false;
		if (result != null) {
			// delete
			mDatastore.delete(result.getKey());
			ret = true;
		}
		return ret;
	}
	    
    public static void deleteAll() {
		Query query = new Query(ENTITY_KIND_USER);
		// get every record from datastore, no filter
		query.setFilter(null);
		// set query's ancestor to get strong consistency
		query.setAncestor(getParentKey());

		PreparedQuery pq = mDatastore.prepare(query);

		for (Entity entity : pq.asIterable()) {
			mDatastore.delete(entity.getKey());
		}
	}
}
