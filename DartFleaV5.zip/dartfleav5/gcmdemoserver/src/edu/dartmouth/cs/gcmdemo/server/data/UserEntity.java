package edu.dartmouth.cs.gcmdemo.server.data;

import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.google.appengine.labs.repackaged.org.json.JSONException;
import com.google.appengine.labs.repackaged.org.json.JSONObject;

public class UserEntity {

//public static String ENTITY_KIND_PARENT = "PostParent";
	//public static String ENTITY_PARENT_KEY = ENTITY_KIND_PARENT;
	private static final Logger mLogger = Logger
			.getLogger(ChatEntity.class.getName());
	
	public static String ENTITY_KIND_USER = "user";

	//public static String FIELD_NAME_DATE = "Date";
	//public static String FIELD_NAME_POST = "Post";

	//public static final String PROPERTY_REG_ID = "Registration_id";
	public static String FIELD_NAME_ID = "id";
	public static String FIELD_NAME_REG_ID = "Registration_id";
	public static String FIELD_NAME_USERNAME = "username";
	public static String FIELD_NAME_EMAIL = "email";
	public static String FIELD_NAME_PASSWORD = "password";
	public static String FIELD_NAME_MOTIVATION = "motivation";
	public static String FIELD_NAME_PHONE = "phone";
	//public static String FIELD_NAME_CONTACTS = "contacts";
	
	public Long id;
	public String mRegid;
	public String mUsername;        
	public String mEmail;     
	public String mPassword;    
	public int mMotivation;        
	public long mPhone;
	
	public UserEntity() {
		
	}

	public UserEntity(Long id, String regid, String username, String email, 
			String password, int motivation,long phone) {
		this.id = id;
		this.mRegid = regid;
		this.mUsername = username;
		this.mEmail = email;
		this.mPassword = password;
		this.mMotivation = motivation;
		this.mPhone = phone;
	}
	
	public UserEntity(JSONObject json){
    	if(json == null){
        	mLogger.log(Level.SEVERE, "UserEntity: json object is null");
        }
        try {
        	this.mRegid = json.getString(FIELD_NAME_REG_ID);
    		this.mUsername = json.getString(FIELD_NAME_USERNAME);
    		this.mEmail = json.getString(FIELD_NAME_EMAIL);
    		this.mPassword = json.getString(FIELD_NAME_PASSWORD);
    		this.mMotivation = json.getInt(FIELD_NAME_MOTIVATION);
    		this.mPhone = json.getLong(FIELD_NAME_PHONE);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
	
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    
	public String getmRegid() {
		return mRegid;
	}
    
    public void setmRegid(String mRegid) {
        this.mRegid = mRegid;
    }

    public String getmUsername() {
        return mUsername;
    }

    public void setUsername(String mUsername) {
        this.mUsername = mUsername;
    }

    public String getmEmail() {
        return mEmail;
    }

    public void setmEmail(String mEmail) {
        this.mEmail = mEmail;
    }

    public String getmPassword() {
        return mPassword;
    }

    public void setmPassword(String mPassword) {
        this.mPassword = mPassword;
    }

    public int getmMotivation() {
        return mMotivation;
    }

    public void setmMotivation(int mMotivation) {
        this.mMotivation = mMotivation;
    }

    public long getmPhone() {
        return mPhone;
    }

    public void setmPhone(long mPhone) {
        this.mPhone = mPhone;
    }
    
    public String toString(){
    	return "id = " + id + ", regid = " + mRegid + ", username = " + mUsername 
    			+ ", email = " + mEmail + ", password = " + mPassword 
    			+ ", notification = " + mMotivation + ", phone = " + mPhone;
    }
}
