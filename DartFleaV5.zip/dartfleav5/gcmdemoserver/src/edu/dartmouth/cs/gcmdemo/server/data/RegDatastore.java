package edu.dartmouth.cs.gcmdemo.server.data;

import java.util.ArrayList;
import java.util.List;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.Key;
//import com.google.appengine.api.datastore.PreparedQuery;
import com.google.appengine.api.datastore.Query;
//import com.google.appengine.api.datastore.Query.Filter;
//import com.google.appengine.api.datastore.Query.FilterOperator;
//import com.google.appengine.api.datastore.Query.SortDirection;

public class RegDatastore {
	private static final DatastoreService mDatastore = DatastoreServiceFactory
			.getDatastoreService();
	public static final String ENTITY_KIND_DEVICE = "Device";
	public static final String DEVICE_REG_ID_PROPERTY = "regId";
	//public static final String DEVICE_USER_ID_PROPERTY = "userId";

	//public static void register(String regId, long userId) {
	public static void register(String regId){
		Entity entity = new Entity(ENTITY_KIND_DEVICE, regId);
		entity.setProperty(DEVICE_REG_ID_PROPERTY, regId);
		//entity.setProperty(DEVICE_USER_ID_PROPERTY, userId);
		mDatastore.put(entity);
	}

	public static List<String> getDevices() {
		List<String> devices;

		Query query = new Query(ENTITY_KIND_DEVICE);
		Iterable<Entity> entities = mDatastore.prepare(query).asIterable();
		devices = new ArrayList<String>();
		for (Entity entity : entities) {
			String device = (String) entity.getProperty(DEVICE_REG_ID_PROPERTY);
			devices.add(device);
		}

		return devices;
	}
	
//	public static long getUserIdByRegId(String regId) {
//        Query query = new Query(ENTITY_KIND_DEVICE);
//        Filter filter = new Query.FilterPredicate(DEVICE_REG_ID_PROPERTY,
//                FilterOperator.EQUAL, regId);
//        query.setFilter(filter);
//
//        // Use PreparedQuery interface to retrieve results
//        PreparedQuery pq = mDatastore.prepare(query);
//
//        Entity result = pq.asSingleEntity();
//        return (Long)result.getProperty(DEVICE_USER_ID_PROPERTY);
//	}
//	
//	public static String getRegIdByUserId(Long userId) {
//        Query query = new Query(ENTITY_KIND_DEVICE);
//        Filter filter = new Query.FilterPredicate(DEVICE_USER_ID_PROPERTY,
//                FilterOperator.EQUAL, userId);
//        query.setFilter(filter);
//
//        // Use PreparedQuery interface to retrieve results
//        PreparedQuery pq = mDatastore.prepare(query);
//
//        Entity result = pq.asSingleEntity();
//        return (String)result.getProperty(DEVICE_REG_ID_PROPERTY);
//	}
	
	public static Key getDeviceKey(String regid) {
		//List<String> devices;

		Query query = new Query(ENTITY_KIND_DEVICE);
		Iterable<Entity> entities = mDatastore.prepare(query).asIterable();
		
		for (Entity entity : entities) {
			String device = (String) entity.getProperty(DEVICE_REG_ID_PROPERTY);
			if(device.equals(regid)){
				return entity.getKey();
			}
		}

		return null;
	}

}
