package edu.dartmouth.cs.gcmdemo.server;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.appengine.labs.repackaged.org.json.JSONArray;
import com.google.appengine.labs.repackaged.org.json.JSONException;
import com.google.appengine.labs.repackaged.org.json.JSONObject;

import edu.dartmouth.cs.gcmdemo.gcm.Message;
import edu.dartmouth.cs.gcmdemo.gcm.Sender;
import edu.dartmouth.cs.gcmdemo.server.data.ChatEntity;
import edu.dartmouth.cs.gcmdemo.server.data.PostDatastore;
import edu.dartmouth.cs.gcmdemo.server.data.PostEntity;
import edu.dartmouth.cs.gcmdemo.server.data.RegDatastore;

public class SendChatToServerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final int MAX_RETRY = 5;
	
	private static final Logger mLogger = Logger
			.getLogger(PostServlet.class.getName());
	
	public static final String PROPERTY_REG_ID = "Registration_id";
    public static final String CONTACT_USER_ID = "contact_user_id";
    public static final String DATE_TIME = "date_time";
    public static final String CONTENT = "content";

	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {
		String msg = req.getParameter("data");
		mLogger.log(Level.INFO, "msg = " + msg);
		try {
			JSONObject json = new JSONObject(msg);
			ChatEntity chat = new ChatEntity(json);
			mLogger.log(Level.INFO, "chat = " + chat.toString());
			
//			long from = chat.getmFrom();
//			long to = chat.getmTo();
//			chat.setmFrom(to);
//			chat.setmTo(from);
			req.setAttribute("chat", chat);
			getServletContext().getRequestDispatcher("/sendChatToContact.do").forward(req, resp);
			//ExerciseEntry entry = new ExerciseEntry(json);
			
			//ExerciseEntryDatastore.add(entry);
			//sendChatToContact(chat);
        } catch (JSONException e) {
            e.printStackTrace();
        }
		
		
	}

	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {
		doPost(req, resp);
	}
}
