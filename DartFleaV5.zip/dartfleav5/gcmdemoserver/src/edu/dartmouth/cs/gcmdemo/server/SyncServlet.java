package edu.dartmouth.cs.gcmdemo.server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

import com.google.appengine.labs.repackaged.org.json.JSONException;
import com.google.appengine.labs.repackaged.org.json.JSONObject;
import com.google.appengine.labs.repackaged.org.json.JSONArray;

import edu.dartmouth.cs.gcmdemo.server.data.PostDatastore;
import edu.dartmouth.cs.gcmdemo.server.data.PostEntity;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class SyncServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {
		   JSONArray array = null;
		   JSONObject jsonObj = null;
		   long id =0 ;
		   String activityType = null;
		   String inputType = null;
		   String dateTime = null;
		   double duration = 0.0;
		   double distance = 0.0;
		   int calories = 0;
		   int heartrate = 0;
		   String comment = null;
		   double climb = 0.0;
		   double avgspeed = 0.0;
		   String regid = null;
		   String unit=null;
		   
		   
		   BufferedReader reader = new BufferedReader(new InputStreamReader(
				   req.getInputStream()));
           String lines;
           StringBuffer sb = new StringBuffer("");
           while ((lines = reader.readLine()) != null) {
               lines = new String(lines.getBytes(), "utf-8");
               sb.append(lines);
           }
           String data = sb.toString().split("=")[1];
           System.out.println("data " + data);
           System.out.println("sb " + sb);
           try{
        	   jsonObj = new JSONObject(data);
        	   regid = jsonObj.getString(PostEntity.PROPERTY_REG_ID);
        	   unit = jsonObj.getString("unit");
        	   System.out.println("regid " + regid);
        	   
        	   PostDatastore.deleteAll(regid);
        	   
        	   array = jsonObj.getJSONArray("array");
          
        	   int size = array.length();
        	 
		
        	   for(int i=0;i<size;i++){
        		   JSONObject obj = array.getJSONObject(i);
			
			
        		   id = obj.getLong("id"); 
        		   inputType = obj.getString("inputType");
        		   activityType = obj.getString("activityType");
        		   dateTime = obj.getString("dateTime");
        		   duration = obj.getDouble("duration");
        		   distance = obj.getDouble("distance");
        		   calories = obj.getInt("calories");
        		   heartrate = obj.getInt("heartrate");
        		   if(obj.has("comment")) {
        			   comment = obj.getString("comment");
        		   }
        		   else {
        			   comment = "";
        		   }
        		   //comment = "test";
        		   climb = obj.getDouble("climb");
        		   avgspeed = obj.getDouble("avgspeed");
		
        		   PostDatastore.add(new PostEntity(regid,id,inputType,activityType, dateTime,duration,distance,calories,
						heartrate,comment,climb,avgspeed,unit));
        	   }		
           }catch(JSONException e){
        	   e.printStackTrace();
           }
           resp.sendRedirect("/query.do");
	}

	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {
		doPost(req, resp);
	}
}
