/*
 * Copyright 2012 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package edu.dartmouth.cs.gcmdemo.server;

import java.io.IOException;
import java.io.OutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.appengine.labs.repackaged.org.json.JSONException;
import com.google.appengine.labs.repackaged.org.json.JSONObject;

import edu.dartmouth.cs.gcmdemo.gcm.Message;
import edu.dartmouth.cs.gcmdemo.server.data.ChatEntity;
import edu.dartmouth.cs.gcmdemo.server.data.ItemDatastore;
import edu.dartmouth.cs.gcmdemo.server.data.ItemEntity;
import edu.dartmouth.cs.gcmdemo.server.data.RegDatastore;
import edu.dartmouth.cs.gcmdemo.server.data.UserDatastore;
import edu.dartmouth.cs.gcmdemo.server.data.UserEntity;

@SuppressWarnings("serial")
public class PostItemServlet extends HttpServlet {
	
	private static final Logger mLogger = Logger
			.getLogger(PostServlet.class.getName());

	private static final String PARAMETER_REG_ID = "regId";
//	private static final String PARAMETER_USER_ID = "userId";
	
	private static long id = 1;

	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {
		String msg = req.getParameter("data");
		mLogger.log(Level.INFO, "msg = " + msg);
		try {
			JSONObject json = new JSONObject(msg);
			ItemEntity item = new ItemEntity(json);
			item.setId(id++);
			mLogger.log(Level.INFO, "item = " + item.toString());
			ItemDatastore.add(item);
			getServletContext().getRequestDispatcher("/download.do")
				.forward(req, resp);

        } catch (JSONException e) {
            e.printStackTrace();
        }
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {
		doPost(req, resp);
	}
}
